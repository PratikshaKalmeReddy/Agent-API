<?php

require_once __DIR__ . '../../install/YtelSeatCount.php';

function ajax_output( $array )
{
    echo json_encode($array);
    exit;
}

/**
 * @return array[total_login_agent, total_outbound_agent, total_closer_agent]
 */
function getCurrentLoginAgent($sendMetric = false) {
    global $link;

    // Get current login users
    $query = "SELECT COUNT(live_agent_id) total_login_agent, SUM(IF(vu.closer_default_blended='1', 1, 0)) total_outbound_agent FROM vicidial_live_agents vla JOIN vicidial_users vu ON vla.user = vu.user";
    $result = mysqli_query($link, $query);
    $row = mysqli_fetch_assoc($result);

    $return  = [
        'total_login_agent' => isset($row['total_login_agent']) && $row['total_login_agent'] ? (int) $row['total_login_agent'] : 0,
        'total_outbound_agent' => isset($row['total_outbound_agent']) && $row['total_outbound_agent'] ? (int) $row['total_outbound_agent'] : 0,
    ];
    $return['total_closer_agent'] = $return['total_login_agent'] - $return['total_outbound_agent'];

    if($sendMetric) {
        try {
//            if(isset($_SESSION['seatCountFromMyytel']) && isset($_SESSION['seatCountFromMyytel']->db)) {
//                $seatCountFromMyytel = $_SESSION['seatCountFromMyytel']->db;
//
//                $maxSeatCount = [
//                    'max_outbound_current' => $seatCountFromMyytel->gumby_max_outbound_cur ? $seatCountFromMyytel->gumby_max_outbound_cur : 0,
//                    'max_closer_current' => $seatCountFromMyytel->gumby_max_closer_cur ? $seatCountFromMyytel->gumby_max_closer_cur : 0,
//                    'max_outbound_billing' => $seatCountFromMyytel->gumby_max_outbound ? $seatCountFromMyytel->gumby_max_outbound : 0,
//                    'max_closer_billing' => $seatCountFromMyytel->gumby_max_closer ? $seatCountFromMyytel->gumby_max_closer : 0,
//                ];
//            } else {
//                $maxSeatCount = [
//                    'max_outbound_current' => null,
//                    'max_closer_current' => null,
//                    'max_outbound_billing' => null,
//                    'max_closer_billing' => null,
//                ];
//            }

            $maxSeatCount = [
                'max_outbound_current' => null,
                'max_closer_current' => null,
                'max_outbound_billing' => null,
                'max_closer_billing' => null,
            ];
       //     $YtelSeatCount = new YtelSeatCount($link);
          //  $YtelSeatCount->notifyLoginAgentCount($return, $maxSeatCount);
        } catch(Exception $ex) {

            $return  = [
                'total_login_agent' => 0,
                'total_outbound_agent' => 0,
                'total_closer_agent' => 0,
            ];
        }
    }

    return $return;
}
