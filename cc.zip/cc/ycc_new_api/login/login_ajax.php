<?php 
    /*
         * Copyright 2024 Ytel, Inc <support@ytel.com>.
         *
         * Ytel, Inc. CONFIDENTIAL
         * ----------------------------------
         * Ytel, Inc.
         * All Rights Reserved.
         * NOTICE:  All information contained herein is, and remains
         * the property of Ytel, Inc. and its suppliers, if any. 
         * The intellectual and technical concepts contained
         * herein are proprietary to Ytel, Inc. and its suppliers and may
         * be covered by U.S. and Foreign Patents, patents in process, and 
         * are protected by trade secret or copyright law.
         * Dissemination of this information or reproduction of this material
         * is strictly forbidden unless prior written permission is obtained
         * from Ytel, Inc.
         *
         * User: Balaji
         * Date: 2/6/2024
         * Time: 12:39
     */


require ("./db/connection.php");
require ("./functions/functions.php");
require "../../agc/functions.php";




 $login =$_REQUEST['login'];
 $pass =$_REQUEST['pass'];


$SSpass_hash_enabled = 0;


$userquery = "SELECT pass_hash_enabled FROM system_settings";

$result = mysqli_query($link, $userquery);
 $qm_conf_array = mysqli_fetch_assoc($result);


if (count($qm_conf_array) > 0)
{

    $SSpass_hash_enabled = $qm_conf_array['pass_hash_enabled'];

}



$user_group_check_flag = false;


$auth_message = user_authorization($login,$pass,'QC',1,'0','0','1','auth');




if ($auth_message =='LOCK')
{
    ajax_output(array(
        'status' => 'error',
        'message' => 'Too many login attempts we locked your login please contract to your manager or ytel support'
    ));
}


if(!$SSpass_hash_enabled){
    $where_sql= "and pass = '{$pass}'";
}else{

    $agent_pass = preg_replace("/\'|\"|\\\\|;| /","",$pass);
    $pass_hash = exec("../../agc/bp.pl --pass=$agent_pass");
    $pass_hash = preg_replace("/PHASH: |\n|\r|\t| /",'',$pass_hash);
    $where_sql= "and pass_hash = '{$pass_hash}'";
}

$userquery = "SELECT COUNT(*) as user_count FROM vicidial_users WHERE user = '{$login}' $where_sql ";
$result = mysqli_query($link, $userquery);
$row = mysqli_fetch_assoc($result);
$user_count = $row['user_count'];
if (!$user_count)
{
    ajax_output(array(
        'status' => 'error',
        'message' => 'Please input a valid username and password.'
    ));
}

$query = "SELECT  user_group ,force_change_password FROM vicidial_users WHERE user = '{$login}' ";
$result = mysqli_query($link, $query);
$row = mysqli_fetch_assoc($result);
$user_group = $row['user_group'];
$force_change_password = $row['force_change_password'];

if ($user_group)
{
    $query = "SELECT  forced_timeclock_login FROM vicidial_user_groups WHERE user_group = '{$user_group}' ";
    $result = mysqli_query($link, $query);
    $row = mysqli_fetch_assoc($result);
    $user_group_check = $row['forced_timeclock_login'];
    if ($user_group_check == 'N')
    {
        $user_group_check_flag = true;

    }
}

$query = "SELECT COUNT(live_agent_id) current_live_user FROM vicidial_live_agents WHERE user = '{$login}'";
$result = mysqli_query($link, $query);
$row = mysqli_fetch_assoc($result);
$current_live_user = $row['current_live_user'];
if ($current_live_user)
{
    ajax_output(array(
        'status' => 'warning',
        'message' => 'The agent you are trying to login is still using the system. If you login now, the system will terminate both of your sessions. If you have further questions, please contact your company administrator.',
        'user_group_check_flag' => $user_group_check_flag,
        'user_group' => $user_group,
        'user_group_check' => $user_group_check,
        'force_change_password'=>$force_change_password
    ));
}

ajax_output(array(
    'status' => 'success',
    'user_group_check_flag' => $user_group_check_flag,
    'user_group' => $user_group,
    'user_group_check' => $user_group_check,
    'force_change_password'=>$force_change_password
));



?>