<?php
error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
define("PROCESS_ROWS_FIRST", 10);
define("PROCESS_ROWS_START", 9000);
define("PROCESS_ROWS_END", 11000);
define("ALLOW_EXTRA_ROWS", 1000);
define("PROCESS_ROWS_SLOW_FIRST", 5);
define("PROCESS_ROWS_SLOW_START", 9);
define("PROCESS_ROWS_SLOW_END", 11);
define("ALLOW_EXTRA_SLOW_ROWS", 1);

//require "../db_mysqli.php";

switch ($_REQUEST['action_type']) {
    case 'login':
        require './login/login_ajax.php';
        //api_log($link, true, 'ytel', '', '', 'cid_callback_queue', $phoneNumber, $returnValue, '', '', '');
        break;
    case 'get_vars':
        require './main/get_vars.php';
        break;

    default:
        echo "For Agent, please use /x5/api/agent.php<br>For Non-Agent, please use /x5/api/non_agent.php";
}
?>