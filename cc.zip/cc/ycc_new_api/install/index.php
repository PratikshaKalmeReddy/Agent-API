<?php
    error_reporting(-1);
    ini_set('display_errors', 1);
    session_start();

    if(isset($_REQUEST['debug'])) {
        $_SESSION['install_debug'] = (bool) $_REQUEST['debug'];
    }

    if(isset($_REQUEST['debug_error_only'])) {
        $_SESSION['install_debug_error_only'] = (bool) $_REQUEST['debug_error_only'];
    }

    if(isset($_SESSION['install_debug_error_only']) && $_SESSION['install_debug_error_only']) {
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
    } elseif(isset($_SESSION['debug']) && $_SESSION['install_debug']) {
        error_reporting(E_ALL ^ E_NOTICE);
        ini_set('display_errors', 1);
    } else {
        error_reporting(-1);
        ini_set('display_errors', 0);
    }

    if($_SERVER["HTTPS"] != "on")
    {
        header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
        exit();
    }

    try {
        // Check access token
        require('./php-jwt-master/src/JWT.php');
        require('./php-jwt-master/src/BeforeValidException.php');
        require('./php-jwt-master/src/ExpiredException.php');
        require('./php-jwt-master/src/JWK.php');
        require('./php-jwt-master/src/SignatureInvalidException.php');

        $jwt = $_COOKIE['accessToken'];
        $publicKey = <<<EOD
-----BEGIN CERTIFICATE-----
MIIDfzCCAmegAwIBAgIEV4UH/jANBgkqhkiG9w0BAQsFADBwMQswCQYDVQQGEwJV
UzELMAkGA1UECBMCQ0ExFDASBgNVBAcTC0xha2UgRm9yZXN0MRIwEAYDVQQKEwlZ
dGVsIEluYy4xFjAUBgNVBAsTDURhdGEgRW5naW5lZXIxEjAQBgNVBAMTCVJ5YW4g
VHJhbjAeFw0xODA5MjUxNjI4NDdaFw0xODEyMjQxNjI4NDdaMHAxCzAJBgNVBAYT
AlVTMQswCQYDVQQIEwJDQTEUMBIGA1UEBxMLTGFrZSBGb3Jlc3QxEjAQBgNVBAoT
CVl0ZWwgSW5jLjEWMBQGA1UECxMNRGF0YSBFbmdpbmVlcjESMBAGA1UEAxMJUnlh
biBUcmFuMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA9A9mPR4QR7pF
lKx2HgLkF6iiNImUCElqgaNyLIyUdCmGNusIfuYBNFrO8vQBN+zuO+vyipT7mXrq
IQD37xUpkXIjP3n5jV6DAjg1t2zNwEfGQRXoYa7TBW2xsTbKlURyysdluOgVYQR4
jlMJeMuXRBTz1hgG/z2W4rSR6J7egJTtnLABNQDQeiVGqWxpuynmgd6dEKZp1u+o
p1FaxSOCW0uWSnO9Og4KOts2lUGHQ615V4mWWPZKo6KchYL/QXOH+TN+nCy6OF/z
IAxs+Bjt7cZZQ2BPAsy4bLL8X9dz9wJTt2mAW05HBOjcAWs8ldvjOqJnTk3dujo2
yi+xdye+mwIDAQABoyEwHzAdBgNVHQ4EFgQUoSa96/E/+3yBkbFs+bj7Ex2e5zMw
DQYJKoZIhvcNAQELBQADggEBAEIKpOjx5HsudkuScsoadxmb7+LVtD05+2yLsvbN
o/g9XmqrY8fhPzgaj6AAWbRDxbcBCET1e5xIyU27qXVQ3gPnKS5gsW53pWmPRYza
DvRfSVPLiUzdhwxITOHkOS4nl5vfa03d7DeVQdL98YF2QrhYDpTp9Cg8ZhHogyPe
9ApplIrZB8Da0pqPk7YB73UpQIJrukG8msY+yGQThKhIIG+yA25olPrfA/8gs7+e
v6vys7lLnz7YkjDyGtfVLz7/VbfllPMgK+V1oeKRtaLZc6TICWjb8Vb3FnB68FJa
suct3cQntLjCFO4AelaQY0EGXTy9EgPGC7PbIYVorDMGcU0=
-----END CERTIFICATE-----
EOD;

        $decoded = \Firebase\JWT\JWT::decode($jwt, $publicKey, array('RS256'));

        $privs = $decoded->privs;
        // Make sure user has the required permission
        if(!isset($privs[1]) || !$privs[1] || ($privs[1] & 16384) !==16384) {
            throw new Exception();
        }

        $adminClientId = $decoded->sub;
        $adminAccountSid = $decoded->acct;

    } catch(\Exception $ex) {
        echo "Error. ER-1980";
        exit;
    }

    require("/srv/www/htdocs/x5/db.php");

    $key = 'X5LmzRrlXXvS1ByAV3F3';

    $result = mysqli_query($link, "SELECT `value` FROM YTEL_extra_settings WHERE setting_key = 'system:installation_key'");
    $row = mysqli_fetch_assoc($result);

    if(isset($row['value'])) {
        $key = $row['value'];
    } else {
        header("Location: /");
        exit; 
    }

    if( !isset($_REQUEST['key']) || $_REQUEST['key'] != $key )
    {
        header("Location: /");
        exit;
    }

    ini_set('display_errors', 1);
    error_reporting(E_ALL ^ E_NOTICE);

    // Seat count V2 and V3 functions
    require_once '../install/YtelSeatCount.php';
    try {
        $YtelSeatCount = new YtelSeatCount($link, true, $adminClientId, $adminAccountSid);
    } catch (Exception $ex) {
        die('Error: '. $ex->getMessage());
    }

    $json = TRUE;
    $status = 0;
    $line = null;
    $message = '';
    $output = '';

    $action = filter_input(INPUT_GET, 'action', FILTER_SANITIZE_STRING);
    if( $action == '' )
        $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);

    try
    {
        switch ($action)
        {
            case 'install-iframe':
                $output .= shell_exec("rm /srv/www/htdocs/index.html");

                // Check if index file removed
                if (file_exists("/srv/www/htdocs/index.html"))
                {
                    throw new Exception("Cannot delete '/srv/www/htdocs/index.html'");
                }

                $output .= shell_exec("cp /srv/www/htdocs/x5/install/files/index.html /srv/www/htdocs/index.html");

                // Check if the file copied
                if (!file_exists("/srv/www/htdocs/index.html"))
                {
                    throw new Exception("Cannot copy '/srv/www/htdocs/x5/install/files/index.html' to '/srv/www/htdocs/index.html'");
                }

                // Check if index file exist
                if (md5_file('/srv/www/htdocs/x5/install/files/index.html') != md5_file('/srv/www/htdocs/index.html'))
                {
                    throw new Exception("'/srv/www/htdocs/x5/install/files/index.html' are not the same '/srv/www/htdocs/index.html'");
                }

                $status = 1;
                $message = "Installed iFrame. Test it here <a href='/' target='_blank'>HERE</a>";

                break;

            case 'remove-tmp-folder':
                $output .= shell_exec("rm -rf /srv/www/htdocs/x5/tmp");

                // Check if tmp folder exists
                if (file_exists("/srv/www/htdocs/x5/tmp"))
                {
                    throw new Exception("Cannot remove tmp folder '/srv/www/htdocs/x5/tmp'");
                }

                $status = 1;
                $message = "tmp folder removed.";

                break;

            case 'create-tmp-folder':
                // Check if tmp folder exists
                if (file_exists("/srv/www/htdocs/x5/tmp"))
                {
                    throw new Exception("tmp folder exists '/srv/www/htdocs/x5/tmp'");
                }

                $output .= shell_exec("mkdir /srv/www/htdocs/x5/tmp");

                // Check if tmp folder exists
                if (!file_exists("/srv/www/htdocs/x5/tmp"))
                {
                    throw new Exception("Cannot create tmp folder '/srv/www/htdocs/x5/tmp'");
                }

                $status = 1;
                $message = "tmp folder created.";

                break;

            case 'change-tmp-folder-permission':
                // Check if tmp folder exists
                if (!file_exists("/srv/www/htdocs/x5/tmp"))
                {
                    throw new Exception("tmp folder does not exist '/srv/www/htdocs/x5/tmp'");
                }

                $output .= shell_exec("chmod 777 /srv/www/htdocs/x5/tmp");

                if (substr(sprintf('%o', fileperms('/srv/www/htdocs/x5/tmp')), -4) != '0777')
                {
                    throw new Exception("Cannot change tmp folder permission '/srv/www/htdocs/x5/tmp'");
                }

                $status = 1;
                $message = "tmp folder permission changed.";

                break;

            case 'setup-advanced-list-rule':

                if( !mysqli_ping($link) )
                {
                    throw new Exception("Mysql connection is not working, please fix this before continue.");
                }


//                $output .= shell_exec("cp /srv/www/htdocs/x5/install/files/admin_ajax.php /srv/www/htdocs/vicidial/admin_ajax.php");
//
//                // Check if the file copied
//                if (!file_exists("/srv/www/htdocs/vicidial/admin_ajax.php"))
//                {
//                    throw new Exception("Cannot copy '/srv/www/htdocs/x5/install/files/admin_ajax.php' to '/srv/www/htdocs/vicidial/admin_ajax.php'");
//                }
//
//                // Check if index file exist
//                if (md5_file('/srv/www/htdocs/x5/install/files/admin_ajax.php') != md5_file('/srv/www/htdocs/vicidial/admin_ajax.php'))
//                {
//                    throw new Exception("'/srv/www/htdocs/x5/install/files/admin_ajax.php' are not the same '/srv/www/htdocs/vicidial/admin_ajax.php'");
//                }
//
//                $message .= "Copied admin_ajax.php to vicidial folder";

                // Check if table exists
                $query = "SHOW TABLES LIKE 'ytel_vicidial_advanced_list_rules'";
                $result = mysqli_query($link, $query);
                if( mysqli_num_rows($result) )
                {
                    $message .= ", ytel_vicidial_advanced_list_rules already exists no need to create";
                }
                else
                {
                    // Create table is not exists
                    $query = "CREATE TABLE `ytel_vicidial_advanced_list_rules` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `from_list_id` BIGINT(14) DEFAULT NULL,
  `from_list_status` VARCHAR(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_list_id` BIGINT(14) DEFAULT NULL,
  `to_list_status` VARCHAR(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `interval` SMALLINT(6) DEFAULT NULL,
  `active` TINYINT(1) DEFAULT NULL,
  `last_run` DATETIME DEFAULT NULL,
  `next_run` DATETIME DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MYISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
                    $result = mysqli_query($link, $query);

                    $query = "SHOW TABLES LIKE 'ytel_vicidial_advanced_list_rules'";
                    $result = mysqli_query($link, $query);
                    if( mysqli_num_rows($result) )
                    {
                        $message .= ", ytel_vicidial_advanced_list_rules table created";
                    }
                    else
                    {
                        throw new Exception("Cannot create table 'ytel_vicidial_advanced_list_rules'");
                    }
                }

                // Check crontab
//                $crontab = shell_exec("crontab -u root -l | grep \"admin_ajax.php\"");
//                if( count($crontab) > 0 )
//                {
//                    $message .= ", crontab already setup no need to install";
//                }
//                else
//                {
//                    throw new Exception($message . ". ** Please install cron manually by ssh to this server as root and exec - <strong>(crontab -l; echo \"*/15 * * * * /usr/bin/php /srv/www/htdocs/vicidial/admin_ajax.php >/dev/null 2>&1\") | crontab -u root -</strong>");

//                    $shall = '(crontab -l; echo "*/15 * * * * /usr/bin/php /srv/www/htdocs/vicidial/admin_ajax.php >/dev/null 2>&1") | crontab -u root -';
//                    $output .= shell_exec($shall);
//
//                    $crontab = shell_exec("crontab -u root -l | grep \"admin_ajax.php\"");
//                    if( count($crontab) > 0 )
//                    {
//                        $message .= ", installed crontab";
//                    }
//                    else
//                    {
//                        throw new Exception("Cannot install cron, please do that manually");
//                    }

//                }


                $status = 1;
                break;
             case 'leadbeam-setup':
                $query = "CREATE TABLE `leadbeam_action_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;   ";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "CREATE TABLE `leadbeam_balances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `balance` decimal(11,4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);




$query = "CREATE TABLE `leadbeam_commissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` int(11) DEFAULT NULL,
  `amount` decimal(11,4) DEFAULT NULL,
  `lead_buyer` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "
CREATE TABLE `leadbeam_dashes` (
  `customer_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `phone_number` bigint(11) DEFAULT NULL,
  `transfer_priority` int(11) DEFAULT '0',
  `minimum_duration` int(11) DEFAULT '0',
  `short_call_duration` int(11) DEFAULT '60',
  `goal` int(11) DEFAULT NULL,
  `repeat_order` int(11) DEFAULT NULL,
  `buffer` int(11) DEFAULT NULL,
  `old_priority` int(11) DEFAULT '-1',
  `paper_priority` int(11) DEFAULT '0',
  `email` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_number` bigint(11) DEFAULT NULL,
  `street` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `referral_commission` decimal(11,4) DEFAULT '0.0000',
  `agent_commission` decimal(11,4) DEFAULT '0.0000',
  `lead_price` decimal(11,4) DEFAULT '0.0000',
  `precheck_paper` int(11) DEFAULT '0',
  `old_p_priority` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `request_order` int(11) DEFAULT '0',
  `refreasons` varchar(1024) COLLATE utf8_unicode_ci DEFAULT 'Incorrect State, Invalid Lead Criteria, Caller Disconnected',
  `rebuy_period` int(11) DEFAULT '30',
  `excl_period` int(11) DEFAULT '0',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `phone_number_UNIQUE` (`phone_number`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);


$query= "
CREATE TABLE `leadbeam_email_report` (
  `id` int(11) NOT NULL,
  `time` time DEFAULT NULL,
  `last_sent` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user` int(11) DEFAULT '0',
  `lead_buyer` int(11) DEFAULT '0',
  `lead_vendor` int(11) DEFAULT '0',
  `leads` int(11) DEFAULT '0',
  `short` int(11) DEFAULT '0',
  `balances` int(11) DEFAULT '0',
  `report` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);


$query = "CREATE TABLE `leadbeam_list` (
  `leadbeam_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(9) unsigned DEFAULT NULL,
  `entry_date` datetime DEFAULT NULL,
  `modify_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(6) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vendor_lead_code` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `source_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `list_id` bigint(14) unsigned NOT NULL DEFAULT '0',
  `gmt_offset_now` decimal(4,2) DEFAULT '0.00',
  `called_since_last_reset` enum('Y','N','Y1','Y2','Y3','Y4','Y5','Y6','Y7','Y8','Y9','Y10') COLLATE utf8_unicode_ci DEFAULT 'N',
  `phone_code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_number` varchar(12) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `title` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middle_initial` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address1` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address3` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(2) COLLATE utf8_unicode_ci DEFAULT NULL,
  `province` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_code` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` enum('M','F','U') COLLATE utf8_unicode_ci DEFAULT 'U',
  `date_of_birth` date DEFAULT NULL,
  `alt_phone` varchar(12) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(70) COLLATE utf8_unicode_ci DEFAULT NULL,
  `security_phrase` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `called_count` smallint(5) unsigned DEFAULT '0',
  `last_local_call_time` datetime DEFAULT NULL,
  `rank` smallint(5) DEFAULT '0',
  `owner` varchar(20) COLLATE utf8_unicode_ci DEFAULT '',
  `entry_list_id` bigint(14) unsigned DEFAULT '0',
  `delivered_to` varchar(1000) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `bought_from` varchar(100) COLLATE utf8_unicode_ci DEFAULT '',
  `custom_fields` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`leadbeam_id`),
  UNIQUE KEY `phone_number` (`phone_number`),
  KEY `list_id` (`list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);


$query = "CREATE TABLE `leadbeam_me_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(45) DEFAULT NULL,
  `leadbeam_user` varchar(45) DEFAULT NULL,
  `x5_contact` varchar(45) DEFAULT NULL,
  `hide_dispute` varchar(45) DEFAULT 'Yes',
  `hide_recordings` varchar(45) DEFAULT 'No',
  `hide_dur` varchar(45) DEFAULT 'No',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "
CREATE TABLE `leadbeam_noqualify_log` (
  `lead_id` int(11) DEFAULT NULL,
  `phone_number` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reasons` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time` timestamp NULL DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_data` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=349 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);


$query = "
CREATE TABLE `leadbeam_notif_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notif` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=373 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "
CREATE TABLE `leadbeam_notifs` (
  `id` int(11) NOT NULL DEFAULT '0',
  `transfer_lead` varchar(10) COLLATE utf8_unicode_ci DEFAULT 'Dashboard',
  `paper_lead` varchar(10) COLLATE utf8_unicode_ci DEFAULT 'Dashboard',
  `order_created` varchar(10) COLLATE utf8_unicode_ci DEFAULT 'Dashboard',
  `order_filled` varchar(10) COLLATE utf8_unicode_ci DEFAULT 'Dashboard',
  `order_80` varchar(10) COLLATE utf8_unicode_ci DEFAULT 'Dashboard',
  `failed_paper` varchar(10) COLLATE utf8_unicode_ci DEFAULT 'Dashboard',
  `no_qual` varchar(10) COLLATE utf8_unicode_ci DEFAULT 'Dashboard',
  `goal` varchar(10) COLLATE utf8_unicode_ci DEFAULT 'Dashboard',
  `order_req` varchar(45) COLLATE utf8_unicode_ci DEFAULT 'Dashboard',
  `refund` varchar(45) COLLATE utf8_unicode_ci DEFAULT 'Dashboard',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "
CREATE TABLE `leadbeam_order` (
  `customer` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `o_thresh` tinyint(4) DEFAULT NULL,
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` int(11) DEFAULT NULL,
  `filled` tinyint(1) DEFAULT '0',
  `notified` tinyint(1) DEFAULT '0',
  `order_placed` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order_finished` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `notes` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_type` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `commission` int(11) DEFAULT '0',
  `buffer` int(11) DEFAULT '0',
  `transaction` int(11) DEFAULT '0',
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=304 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);


$query = "CREATE TABLE `leadbeam_order_leads` (
  `order_id` int(11) DEFAULT NULL,
  `leadbeam_id` int(11) DEFAULT NULL,
  `recording_id` int(11) DEFAULT '0',
  `order_lead_id` int(11) NOT NULL AUTO_INCREMENT,
  `recording_date` timestamp NULL DEFAULT NULL,
  `type` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `delivered` int(11) DEFAULT '0',
  `refunded` int(11) DEFAULT '0',
  `disputed` int(11) DEFAULT '0',
  `reason` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `agent_id` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `response` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`order_lead_id`)
) ENGINE=MyISAM AUTO_INCREMENT=34862 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "
CREATE TABLE `leadbeam_post` (
  `leadbeam_post_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `type` int(11) DEFAULT '1',
  `url` varchar(1024) DEFAULT NULL,
  `campaign` varchar(45) DEFAULT NULL,
  `campaign_id` varchar(40) DEFAULT NULL,
  `list_id` varchar(40) DEFAULT NULL,
  `format` varchar(45) DEFAULT 'http',
  `success` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`leadbeam_post_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "
CREATE TABLE `leadbeam_post_out` (
  `post_out_id` int(11) NOT NULL AUTO_INCREMENT,
  `field` varchar(45) DEFAULT NULL,
  `value` varchar(45) DEFAULT NULL,
  `regex` varchar(45) DEFAULT NULL,
  `customer` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `list_id` varchar(40) DEFAULT NULL,
  `campaign_id` varchar(40) DEFAULT NULL,
  `rank` int(11) DEFAULT NULL,
  PRIMARY KEY (`post_out_id`)
) ENGINE=MyISAM AUTO_INCREMENT=865 DEFAULT CHARSET=utf8;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "
CREATE TABLE `leadbeam_postout_reports` (
  `leadbeam_id` int(11) NOT NULL,
  `postdata` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `success` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `response` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `lead_buyer` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`report_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8686 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);


if(mysqli_errno($link))
    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);


$query = "CREATE TABLE `leadbeam_recording_log` (
  `recording_id` int(11) NOT NULL DEFAULT '0',
  `length_in_sec` int(11) DEFAULT NULL,
  `lead_id` int(11) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `extension` bigint(12) DEFAULT NULL,
  `user` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`recording_id`),
  KEY `idx_leadbeam_recording_log_extension` (`extension`) COMMENT 'for matching to lead buyers',
  KEY `idx_leadbeam_recording_log_lead_id` (`lead_id`) COMMENT 'for matching to lead list',
  KEY `idx_leadbeam_recording_log_user` (`user`) COMMENT 'for matching to vendor DiDs'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "CREATE TABLE `leadbeam_reports` (
  `id` int(11) NOT NULL,
  `interval` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `period` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);


                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "CREATE TABLE `leadbeam_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `active` tinyint(4) DEFAULT '1',
  `campaign_id` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `applies_to` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ruletype` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `list_id` varchar(40) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` mediumtext COLLATE utf8_unicode_ci,
  `field` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1080 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);

                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "
CREATE TABLE `leadbeam_settings` (
  `text_number` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings_id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_rules` int(11) DEFAULT '0',
  `allow_posts` int(11) DEFAULT '0',
  `display_3rd` int(11) DEFAULT '0',
  `maptotal` int(11) DEFAULT '0',
  `post_out` int(11) DEFAULT '0',
  `hourly_update` int(11) DEFAULT '0',
  `email_address` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `db_id` int(11) DEFAULT '0',
  `decisioning` int(11) DEFAULT '0',
  `quick_transfer` int(11) DEFAULT '0',
  `transfer` varchar(45) COLLATE utf8_unicode_ci DEFAULT '3way',
  `auto_post` int(11) DEFAULT '0',
  `company_id` int(11) DEFAULT '100327',
  `transfer_tiers` varchar(100) COLLATE utf8_unicode_ci DEFAULT '{\"0\":\"0\", \"0.1400\":\"2500\", \"0.4900\":\"8500\", \"0.7400\":\"14500\", \"0.8400\":\"20000\"}',
  `paper_tiers` varchar(100) COLLATE utf8_unicode_ci DEFAULT '0',
  `x5website` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marginal` int(11) DEFAULT '0',
  `m360Sid` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `m360Token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`settings_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
";
                $result = mysqli_query($link, $query);

               if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query ="
CREATE TABLE `leadbeam_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(11,4) DEFAULT NULL,
  `name` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=178 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);

               if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);

$query = "
CREATE TABLE `leadbeam_vendors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_id` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `vendor` varchar(45) COLLATE utf8_unicode_ci DEFAULT 'NULL',
  `DiD` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_number` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zipcode` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lead_cost` decimal(11,4) DEFAULT '0.0000',
  `p_lead_cost` decimal(11,4) DEFAULT '0.0000',
  `resell-attempts` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;";
                $result = mysqli_query($link, $query);

               if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);
$query = "
CREATE  PROCEDURE `leadbeam_list_sync`(
    in p_lead_id char(10),
    in p_modify_date char(45),
    in p_status char(45),
    in p_user   char(45),
    in p_vendor_lead_code char(45),
    in p_source_id char(45),
    in p_list_id   char(45),
    in p_gmt_offset_now char(45),
    in p_called_since_last_reset char(45),
    in p_phone_code char(45),
    in p_phone_number char(45),
    in p_title        char(45),
    in p_first_name char(45),
    in p_middle_initial char(45),
    in p_last_name char(45),
    in p_address1 char(45),
    in p_address2 char(45),
    in p_address3 char(45),
    in p_city char(45),
    in p_state char(45),
    in p_province char(45),
    in p_postal_code char(45),
    in p_country_code char(45),
    in p_gender char(45),
    in p_date_of_birth char(45),
    in p_alt_phone char(45),
    in p_email char(45),
    in p_security_phrase char(45),
    in p_comments char(45),
    in p_called_count char(45),
    in p_last_local_call_time char(45),
    in p_rank char(45),
    in p_owner char(45),
    in p_entry_list_id char(45),
    in p_delivered_to char(45),
    in p_bought_from char(45),
    in p_custom_fields text)
BEGIN
declare continue Handler for 1062
update leadbeam_list set lead_id =p_lead_id,
     modify_date =now(),
     status =p_status,
     user  =p_user ,
     vendor_lead_code =p_vendor_lead_code ,
     source_id =p_source_id ,
     list_id =p_list_id   ,
     gmt_offset_now  =p_gmt_offset_now,
     called_since_last_reset = p_called_since_last_reset ,
     phone_code = p_phone_code,
     title  =p_title      ,
     first_name =p_first_name ,
     middle_initial = p_middle_initial,
     last_name =p_last_name,
     address1 = p_address1 ,
     address2 =p_address2 ,
     address3 =p_address3,
     city = p_city ,
     state = p_state ,
     province = p_province ,
     postal_code = p_postal_code ,
     country_code =p_country_code ,
          gender = p_gender ,
     date_of_birth = p_date_of_birth ,
     alt_phone =p_alt_phone ,
     email = p_email ,
     security_phrase = p_security_phrase ,
     comments = p_comments ,
     called_count = p_called_count ,
     last_local_call_time = p_last_local_call_time ,
     rank = p_rank ,
     owner =p_owner,
     entry_list_id = p_entry_list_id,
     custom_fields =p_custom_fields    where phone_number = p_phone_number;
insert into leadbeam_list values ( NULL, p_lead_id , now(),
     p_modify_date ,
     p_status ,
     p_user   ,
     p_vendor_lead_code ,
     p_source_id ,
     p_list_id   ,
     p_gmt_offset_now ,
     p_called_since_last_reset ,
     p_phone_code ,
     p_phone_number ,
     p_title        ,
     p_first_name ,
     p_middle_initial ,
     p_last_name ,
     p_address1 ,
     p_address2 ,
     p_address3 ,
     p_city ,
     p_state ,
     p_province ,
     p_postal_code ,
     p_country_code ,
     p_gender ,
     p_date_of_birth ,
     p_alt_phone ,
     p_email ,
     p_security_phrase ,
     p_comments ,
     p_called_count ,
     p_last_local_call_time ,
     p_rank ,
     p_owner ,
     p_entry_list_id ,
     p_delivered_to ,
     p_bought_from ,
     p_custom_fields);
END;
";
                $result = mysqli_query($link, $query);

                if(mysqli_errno($link))
                    throw new Exception("Database failed to build!" . mysqli_error($link) . " Query: " . $query);
                $status = 1;
                break;
            case 'setup-max-allowed-login-user':
                // Check for limiting users
                $query = "SHOW columns FROM system_settings where Field IN ('max_allowed_login_user', 'company_id', 'max_allowed_login_user_last_update', 'max_allowed_login_user_updated_by')";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot add max_allowed_login_user col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);

                //Setup col
                while ($row = mysqli_fetch_assoc($result))
                {
                    $query = "ALTER TABLE `system_settings` DROP COLUMN `{$row['Field']}`";
                    mysqli_query($link_custom, $query);
                    if(mysqli_errno($link_custom))
                        throw new Exception("Cannot add max_allowed_login_user col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);
                }

                $query = "ALTER TABLE `system_settings` ADD COLUMN `max_allowed_login_user` MEDIUMINT NULL DEFAULT NULL AFTER `frozen_server_call_clear`, ADD COLUMN `company_id` INT NULL DEFAULT NULL AFTER `max_allowed_login_user`, ADD COLUMN `max_allowed_login_user_last_update` DATETIME NULL AFTER `company_id`, ADD COLUMN `max_allowed_login_user_updated_by` VARCHAR(20) NULL AFTER `max_allowed_login_user_last_update`";
                $result = mysqli_query($link_custom, $query);
                if(mysqli_errno($link_custom))
                    throw new Exception("Cannot add max_allowed_login_user col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);

                $query = "SHOW columns FROM system_settings LIKE 'max_allowed_login_user'";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot add max_allowed_login_user col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);
                if( !mysqli_num_rows($result) )
                {
                    throw new Exception("Cannot add max_allowed_login_user col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);
                }

                $YtelSeatCount->notifyEnableSeatCount(1);

                $status = 1;
                $message = "Database setup! Please input the company ID associated to this system and sync the setting from my.ytel and DTH";

                break;

            case 'setup-max-allowed-login-user-version-2':
                // Check for limiting users
                $query = "SHOW columns FROM system_settings where Field IN ('max_allowed_login_user_outbound', 'max_allowed_login_user_closer')";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot add max_allowed_login_user col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);

                //Setup col
                while ($row = mysqli_fetch_assoc($result))
                {
                    $query = "ALTER TABLE `system_settings` DROP COLUMN `{$row['Field']}`";
                    mysqli_query($link_custom, $query);
                    if(mysqli_errno($link_custom))
                        throw new Exception("Cannot add max_allowed_login_user col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);
                }

                $query = "ALTER TABLE `system_settings` ADD COLUMN `max_allowed_login_user_outbound` MEDIUMINT NULL DEFAULT NULL AFTER `max_allowed_login_user`, ADD COLUMN `max_allowed_login_user_closer` MEDIUMINT NULL DEFAULT NULL AFTER `max_allowed_login_user_outbound`";
                $result = mysqli_query($link_custom, $query);
                if(mysqli_errno($link_custom))
                    throw new Exception("Cannot add max_allowed_login_user col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);

                $query = "SHOW columns FROM system_settings where Field IN ('max_allowed_login_user', 'company_id', 'max_allowed_login_user_last_update', 'max_allowed_login_user_updated_by', 'max_allowed_login_user_outbound', 'max_allowed_login_user_closer')";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot add required col for max allowed login user version 2. Error: " . mysqli_error($link) . " Query: " . $query);
                if( mysqli_num_rows($result) != 6 )
                {
                    throw new Exception("Cannot add required col for max allowed login user version 2. Error: " . mysqli_error($link) . " Query: " . $query);
                }

                $YtelSeatCount->notifyEnableSeatCount(2);

                $status = 1;
                $message = "Database setup! Please input the company ID associated to this system and sync the setting from my.ytel";

                break;

            case 'setup-max-allowed-login-user-version-3':
                // Check for limiting users
                $query = "SHOW columns FROM system_settings where Field IN ('cluster_id')";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot add cluster_id col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);

                $query = "ALTER TABLE `system_settings` ADD COLUMN `cluster_id` INT NULL DEFAULT NULL AFTER `company_id`;";
                $result = mysqli_query($link_custom, $query);
                if(mysqli_errno($link_custom))
                    throw new Exception("Cannot add cluster_id col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);

                $query = "SHOW columns FROM system_settings where Field IN ('max_allowed_login_user', 'company_id', 'cluster_id', 'max_allowed_login_user_last_update', 'max_allowed_login_user_updated_by', 'max_allowed_login_user_outbound', 'max_allowed_login_user_closer')";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot add required col for max allowed login user with cluster. Error: " . mysqli_error($link) . " Query: " . $query);
                if( mysqli_num_rows($result) != 7 )
                {
                    throw new Exception("Cannot add required col for max allowed login user with cluster. Error: " . mysqli_error($link) . " Query: " . $query);
                }

                $YtelSeatCount->notifyEnableSeatCount(3);

                $status = 1;
                $message = "Database setup! Please input the Cluster ID associated to this system and sync the setting from my.ytel";

                break;

            case 'disable-max-allowed-login-user':
                // Check for limiting users
                $query = "SHOW columns FROM system_settings where Field IN ('max_allowed_login_user', 'company_id', 'cluster_id', 'max_allowed_login_user_last_update', 'max_allowed_login_user_updated_by', 'max_allowed_login_user_outbound', 'max_allowed_login_user_closer')";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                        throw new Exception("Cannot disable max_allowed_login_user col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);
                //Setup col
                while ($row = mysqli_fetch_assoc($result))
                {
                    $query = "ALTER TABLE `system_settings` DROP COLUMN `{$row['Field']}`";
                    mysqli_query($link_custom, $query);
                    if(mysqli_errno($link_custom))
                        throw new Exception("Cannot disable max_allowed_login_user col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);
                }

                $YtelSeatCount->notifyDisableSeatCount(1);

                $status = 1;
                $message = "Disabled max allowed login user";
                break;

            case 'disable-max-allowed-login-user-version-2':
                // Check for limiting users
                $query = "SHOW columns FROM system_settings where Field IN ('max_allowed_login_user_outbound', 'max_allowed_login_user_closer')";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                        throw new Exception("Cannot disable max allowed login user version 2. Error: " . mysqli_error($link) . " Query: " . $query);
                //Setup col
                while ($row = mysqli_fetch_assoc($result))
                {
                    $query = "ALTER TABLE `system_settings` DROP COLUMN `{$row['Field']}`";
                    mysqli_query($link_custom, $query);
                    if(mysqli_errno($link_custom))
                        throw new Exception("Cannot disable max allowed login user version 2. Error: " . mysqli_error($link) . " Query: " . $query);
                }

                $YtelSeatCount->notifyDisableSeatCount(2);

                $status = 1;
                $message = "Disabled max allowed login user";
                break;

            case 'disable-max-allowed-login-user-version-3':
                // Check for limiting users
                $query = "SHOW columns FROM system_settings where Field IN ('cluster_id')";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot disable max allowed login user version 3. Error: " . mysqli_error($link) . " Query: " . $query);
                //Setup col
                while ($row = mysqli_fetch_assoc($result))
                {
                    $query = "ALTER TABLE `system_settings` DROP COLUMN `{$row['Field']}`";
                    mysqli_query($link_custom, $query);
                    if(mysqli_errno($link_custom))
                        throw new Exception("Cannot disable max allowed login user version 3. Error: " . mysqli_error($link) . " Query: " . $query);
                }

                $YtelSeatCount->notifyDisableSeatCount(3);

                $status = 1;
                $message = "Disabled max allowed login user";
                break;

            case 'get-max-allowed-login-user-settings':
                $output = $YtelSeatCount->getSeatCount();
                $output['seat_count_version'] = $YtelSeatCount->getSeatCountVersion();
                break;

            case 'get-max-allowed-login-user-settings-myytel':
                $output = $YtelSeatCount->getSeatCountFromMyYtel();
                break;

            case 'update-max-allowed-login-setting':
                $company_id = filter_input(INPUT_POST, 'company_id', FILTER_SANITIZE_NUMBER_INT);
                if( $company_id == '' )
                    $company_id = 'NULL';

                $cluster_id = filter_input(INPUT_POST, 'cluster_id', FILTER_SANITIZE_NUMBER_INT);
                if( $cluster_id == '' )
                    $cluster_id = 'NULL';

                $colCount = $YtelSeatCount->getSeatCountVersion();
                if( $colCount == 4 )
                {
                    $query = "UPDATE system_settings SET company_id = $company_id";
                } else if( $colCount == 6 ) {
                    $query = "UPDATE system_settings SET company_id = $company_id";
                } else if( $colCount == 7 ) {
                    $query = "UPDATE system_settings SET company_id = $company_id, cluster_id = $cluster_id";
                }

                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot save max allowed login user settings. Error: " . mysqli_error($link) . " Query: " . $query);

                // Update my.ytel seat count
                $data = $YtelSeatCount->notifyUpdateManualSeatCount(-2, -2);

                $status = 1;
                $message = "Saved max allowed login user settings " . $data;

                break;

            case 'set-max-allowed-login-user':
                $max_allowed_login_user = filter_input(INPUT_POST, 'max_allowed_login_user', FILTER_SANITIZE_NUMBER_INT);
                if( $max_allowed_login_user == '' )
                    $max_allowed_login_user = 'NULL';

                $max_allowed_login_user_outbound = filter_input(INPUT_POST, 'max_allowed_login_user_outbound', FILTER_SANITIZE_NUMBER_INT);
                if( $max_allowed_login_user_outbound == '' )
                    $max_allowed_login_user_outbound = 0;

                $max_allowed_login_user_closer = filter_input(INPUT_POST, 'max_allowed_login_user_closer', FILTER_SANITIZE_NUMBER_INT);
                if( $max_allowed_login_user_closer == '' )
                    $max_allowed_login_user_closer = 0;

                $api_funded = filter_input(INPUT_POST, 'api_funded', FILTER_SANITIZE_NUMBER_INT);
                if( $api_funded == '' )
                    $api_funded = 1;

                $seatCountSettings = $YtelSeatCount->getSeatCountSettings();

                $colCount = $YtelSeatCount->getSeatCountVersion();
                if( $colCount == $YtelSeatCount::SEAT_COUNT_VERSION_1 )
                {
                    $query = "UPDATE system_settings SET api_funded = {$api_funded}, max_allowed_login_user = $max_allowed_login_user, max_allowed_login_user_last_update = NOW(), max_allowed_login_user_updated_by = 'X5 Installer'";
                } else if( $colCount == $YtelSeatCount::SEAT_COUNT_VERSION_2 ) {
                    $query = "UPDATE system_settings SET api_funded = {$api_funded}, max_allowed_login_user = null, max_allowed_login_user_outbound = $max_allowed_login_user_outbound, max_allowed_login_user_closer = $max_allowed_login_user_closer, max_allowed_login_user_last_update = NOW(), max_allowed_login_user_updated_by = 'X5 Installer'";
                } else if( $colCount == $YtelSeatCount::SEAT_COUNT_VERSION_3 ) {
                    $query = "UPDATE system_settings SET api_funded = {$api_funded}, max_allowed_login_user = null, max_allowed_login_user_outbound = $max_allowed_login_user_outbound, max_allowed_login_user_closer = $max_allowed_login_user_closer, max_allowed_login_user_last_update = NOW(), max_allowed_login_user_updated_by = 'X5 Installer'";
                }

                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot save max allowed login user settings. Error: " . mysqli_error($link) . " Query: " . $query);

                // Update my.ytel seat count
                $data = $YtelSeatCount->notifyUpdateManualSeatCount($max_allowed_login_user_outbound, $max_allowed_login_user_closer);

                $status = 1;
                $message = "Saved max allowed login user settings " . $data;

                break;

            case 'set-max-allowed-login-user-api-funded':
                $api_funded = filter_input(INPUT_POST, 'api_funded', FILTER_SANITIZE_NUMBER_INT);
                if( $api_funded == '' )
                    $api_funded = 1;

                $colCount = $YtelSeatCount->getSeatCountVersion();
                if( $colCount == $YtelSeatCount::SEAT_COUNT_VERSION_1 )
                {
                    $query = "UPDATE system_settings SET api_funded = {$api_funded}";
                } else if( $colCount == $YtelSeatCount::SEAT_COUNT_VERSION_2 ) {
                    $query = "UPDATE system_settings SET api_funded = {$api_funded}";
                } else if( $colCount == $YtelSeatCount::SEAT_COUNT_VERSION_3 ) {
                    $query = "UPDATE system_settings SET api_funded = {$api_funded}";
                }

                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot save max allowed login user settings. Error: " . mysqli_error($link) . " Query: " . $query);

                $isActive = $YtelSeatCount::isApiFunded($api_funded);
                if($isActive) {
                    $YtelSeatCount->turnOnOutbound();
                } else {
                    $YtelSeatCount->turnOffOutbound();
                }

                // Update my.ytel seat count
                $data = $YtelSeatCount->notifyUpdateManualSeatCount(-5, $api_funded);

                $status = 1;
                $message = "Saved max allowed login user settings " . $data;

                break;

            case 'sync-max-allowed-login-user':
                // Update my.ytel
                $data = $YtelSeatCount->notifyUpdateManualSeatCount(-1, -1);

                $colCount = $YtelSeatCount->getSeatCountVersion();

                $status = 1;
                $output_from_myytel = $YtelSeatCount->getSeatCountFromMyYtel();
                if(!isset($output_from_myytel->max_outbound) || !isset($output_from_myytel->max_closer)) {
                    throw new Exception('Cannot sync seat count.');
                }

                $max_allowed_login_user = $output_from_myytel->max_user;
                if( $max_allowed_login_user == '' )
                    $max_allowed_login_user = 'NULL';

                $max_allowed_login_user_outbound = $output_from_myytel->max_outbound;
                if( $max_allowed_login_user_outbound == '' )
                    $max_allowed_login_user_outbound = 0;

                $max_allowed_login_user_closer = $output_from_myytel->max_closer;
                if( $max_allowed_login_user_closer == '' )
                    $max_allowed_login_user_closer = 0;

                $api_funded = $output_from_myytel->api_funded ? 1 : 0;

                if( $colCount == 4 )
                {
                    $query = "UPDATE system_settings SET api_funded = {$api_funded}, max_allowed_login_user = $max_allowed_login_user, max_allowed_login_user_last_update = NOW(), max_allowed_login_user_updated_by = 'my.ytel'";
                } else {
                    $query = "UPDATE system_settings SET api_funded = {$api_funded}, max_allowed_login_user = $max_allowed_login_user, max_allowed_login_user_outbound = $max_allowed_login_user_outbound, max_allowed_login_user_closer = $max_allowed_login_user_closer, max_allowed_login_user_last_update = NOW(), max_allowed_login_user_updated_by = 'my.ytel'";
                }

                if($YtelSeatCount::isApiFunded($api_funded)) {
                    $YtelSeatCount->turnOnOutbound();
                } else {
                    $YtelSeatCount->turnOffOutbound();
                }

                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot save max allowed login user settings. Error: " . mysqli_error($link) . " Query: " . $query);

                $status = 1;
                $message = "Synced max allowed login user settings";

                break;

            case "enable-chat":
                $query = "ALTER TABLE `system_settings` ADD COLUMN `chat_room_id` VARCHAR(100) NULL AFTER `frozen_server_call_clear`, ADD COLUMN `chat_room_server` VARCHAR(45) NULL AFTER `chat_room_id`;";
                $result = mysqli_query($link_custom, $query);
                if(mysqli_errno($link_custom))
                    throw new Exception("Cannot add chat_room required col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);

                $status = 1;
                $message = "Datebase setup finished! Added required col to system table.";

                break;

            case "disable-chat":
                $query = "ALTER TABLE `system_settings` DROP COLUMN `chat_room_server`, DROP COLUMN `chat_room_id`;";
                $result = mysqli_query($link_custom, $query);
                if(mysqli_errno($link_custom))
                    throw new Exception("Cannot remove chat_room col from system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);

                $status = 1;
                $message = "Clean up database!";
                break;

            case 'get-chat-settings':
                $query = "SELECT chat_room_id, chat_room_server FROM system_settings LIMIT 1";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Error getting chat room settings. Error: " . mysqli_error($link) . " Query: " . $query);
                $output = mysqli_fetch_assoc($result);

                break;

            case 'update-chat-setting':
                $chat_room_id = filter_input(INPUT_POST, 'chat_room_id');
                if( $chat_room_id == '' )
                    $chat_room_id = 'NULL';
                $chat_room_server = filter_input(INPUT_POST, 'chat_room_server');
                if( $chat_room_server == '' )
                    $chat_room_server = 'NULL';

                $query = "UPDATE system_settings SET chat_room_id = '$chat_room_id', chat_room_server = '$chat_room_server'";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot save chat room settings. Error: " . mysqli_error($link) . " Query: " . $query);

                $status = 1;
                $message = "Saved chat room settings";

                break;

            case 'enable-x5-prime':
                $query = "ALTER TABLE `system_settings` ADD COLUMN `x5_theme` VARCHAR(100) NULL AFTER `frozen_server_call_clear`;";
                $result = mysqli_query($link_custom, $query);
                if(mysqli_errno($link_custom))
                    throw new Exception("Cannot add x5_theme required col to system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);

                $query = "UPDATE system_settings SET x5_theme = 'x5-prime'";
                $result = mysqli_query($link, $query);
                if(mysqli_errno($link))
                    throw new Exception("Cannot save theme settings. Error: " . mysqli_error($link) . " Query: " . $query);

                $status = 1;
                $message = "Datebase setup finished! Added required col to system table.";
                break;

            case 'disable-x5-prime':
                $query = "ALTER TABLE `system_settings` DROP COLUMN `x5_theme`;";
                $result = mysqli_query($link_custom, $query);
                if(mysqli_errno($link_custom))
                    throw new Exception("Cannot remove x5_theme col from system_settings table. Error: " . mysqli_error($link) . " Query: " . $query);

                $status = 1;
                $message = "Clean up database!";
                break;

            case "update-chat-2-setting":
                $query = "DELETE FROM YTEL_extra_settings WHERE setting_key IN ('x5:domain', 'chat2:database')";
                mysqli_query($link, $query);

                $query = "INSERT INTO YTEL_extra_settings (setting_key, `value`) VALUES ('x5:domain', '{$_REQUEST['x5_domain']}'), ('chat2:database', '{$_REQUEST['chat2_database']}')";

                $result = mysqli_query($link, $query);

                if(mysqli_errno($link_custom))
                    throw new Exception("Cannot add chat info. Error: " . mysqli_error($link) . " Query: " . $query);

                $status = 1;
                $message = "Database setup finished!";

                break;

            case "disable-chat-2":
                $query = "DELETE FROM YTEL_extra_settings WHERE setting_key IN ('x5:domain', 'chat2:database')";
                mysqli_query($link, $query);

                if(mysqli_errno($link_custom))
                    throw new Exception("Cannot delete chat info. Error: " . mysqli_error($link) . " Query: " . $query);

                $status = 1;
                $message = "Ytel Chat disabled!";

                break;

            case "get-current-login-agent":
                require_once '../functions.php';

                $status = 1;
                $output = getCurrentLoginAgent();
                break;

            default:
                $json = FALSE;

                // Check x5 folder owner
                if( function_exists('posix_getpwuid') )
                {
                    $test['package-posix'] = TRUE;

                    clearstatcache('/srv/www/htdocs/x5');

                    $owner = posix_getpwuid(fileowner('/srv/www/htdocs/x5'));
                    $test['x5-folder-owner'] = ($owner['name'] == 'wwwrun');

                    $group = posix_getgrgid(filegroup('/srv/www/htdocs/x5'));
                    $test['x5-folder-group'] = ($group['name'] == 'www');
                }
                else
                {
                    $test['package-posix'] = FALSE;
                }

                // Check iFrame
                $test['install-iframe'] = (md5_file('/srv/www/htdocs/x5/install/files/index.html') == md5_file('/srv/www/htdocs/index.html'));
                $test['create-tmp-folder'] = file_exists("/srv/www/htdocs/x5/tmp");
                $test['change-tmp-folder-permission'] = ($test['create-tmp-folder'] && substr(sprintf('%o', fileperms('/srv/www/htdocs/x5/tmp')), -4) == '0777');

                // Check mysql connection
                try {
                    $test['mysql-connection'] = mysqli_ping($link);
                } catch (\Exception $ex) {
                    $test['mysql-connection'] = false;
                }


                // Check advanced list rule
                try {
                    $query = "SHOW TABLES LIKE 'ytel_vicidial_advanced_list_rules'";
                    $result = mysqli_query($link, $query);
                    $test['setup-advanced-list-rule'] = mysqli_num_rows($result);
                } catch (\Exception $ex) {
                    $test['setup-advanced-list-rule'] = false;
                }

                // Check max allowed login user
                if( $test['mysql-connection'] )
                {
                    $seatCountVersion = $YtelSeatCount->getSeatCountVersion();
                    $test['setup-max-allowed-login-user'] = $seatCountVersion == $YtelSeatCount::SEAT_COUNT_VERSION_1;
                    $test['setup-max-allowed-login-user-version-2'] = $seatCountVersion == $YtelSeatCount::SEAT_COUNT_VERSION_2;
                    $test['setup-max-allowed-login-user-version-3'] = $seatCountVersion == $YtelSeatCount::SEAT_COUNT_VERSION_3;
                }
                else
                {
                    $test['setup-max-allowed-login-user'] = FALSE;
                }

                // Check chat
                if( $test['mysql-connection'] )
                {
                    $query = "SHOW columns FROM system_settings where Field IN('chat_room_id', 'chat_room_server')";
                    $result = mysqli_query($link, $query);
                    $test['setup-chat'] = ( mysqli_num_rows($result) == 2 ) ? TRUE : FALSE;
                }
                else
                {
                    $test['setup-chat'] = FALSE;
                }

                // Check x5-theme
                if( $test['mysql-connection'] )
                {
                    $query = "SHOW columns FROM system_settings where Field IN('x5_theme')";
                    $result = mysqli_query($link, $query);
                    $test['x5-theme'] = ( mysqli_num_rows($result) == 1 ) ? TRUE : FALSE;
                }
                else
                {
                    $test['x5-theme'] = FALSE;
                }

                $query = "SELECT setting_key, `value` FROM YTEL_extra_settings WHERE setting_key IN ('x5:domain', 'chat2:database')";

                $result = mysqli_query($link, $query);
                while($row = mysqli_fetch_assoc( $result )) {
                    $test[$row['setting_key']] = $row['value'];
                }
        }
    } catch (Exception $e)
    {
        $json = TRUE;
        $line = $e->getLine();
        $message = $e->getMessage();
    }

    if ($json)
    {
        header("Content-type: application/json");
        die(json_encode(array('status' => $status, 'message' => $message, 'line' => $line, 'output' => $output)));
    }
?>

<html>
    <head>
        <title>X5 Installation</title>

        <link rel='shortcut icon' type='image/x-icon' href='/x5/favicon.ico' />

        <link rel="stylesheet" href="css/bootstrap.min.css">

        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>

        <style>
            input {
                padding: 0;
                height: 30px;
                line-height: 1.5px;
                font-size: 15px;
            }

            #max-allowed-login-user-section, #chat-section, #x5-theme-section {
                display: none;
            }

            .green {
                background-color: green;
            }
        </style>

    </head>
    <body>
        <div class="container" style="margin-top: 30px;">
            <div class="well well-lg" id="main-control">

                <?php if(!$test['package-posix']) { ?>
                    <div class="alert alert-warning">
                        <p>Posix is not installed on the server, we cannot check x5 folder owner. Please make sure X5 folder is owned by <strong>wwwrun:www</strong>; otherwise, the installer won't work correctlly. (SSH to the server as root and exec - <strong>chown wwwrun:www /srv/www/htdocs/x5</strong>)</p>
                        <p>If you want to install posix, ssh to the server as root and exec - <strong>zypper install php-posix</strong> and restart apache after the installation - <strong>rcapache2 restart</strong></p>
                    </div>
                <?php } else { ?>
                    <?php if(!$test['x5-folder-owner'] || !$test['x5-folder-group']) { ?>
                    <div class="alert alert-danger">X5 folder is not owned by <strong>wwwrun:www</strong>, the installer won't work correctlly. Current: <?php echo $owner['name'].":".$group['name']; ?>. (SSH to the server as root and exec - <strong>chown wwwrun:www /srv/www/htdocs/x5</strong>)</div>
                    <?php } ?>
                <?php } ?>

                <?php if(!$test['mysql-connection']) { ?>
                    <div class="alert alert-danger">Mysql connection is not working, you won't be able to setup Advanced List Rule and other database related settings using this installer.</div>
                <?php } ?>

                <h2>X5 Installation Check List</h2>
                <div>
                    <fieldset>
                        <legend>Required Steps</legend>
                        <ul style="line-height: 30px;">
                            <?php $class = ($test['install-iframe']) ? 'btn-success' : 'btn-primary'; ?>
                            <li><button type="button" class="btn btn-xs btn-exec <?php echo $class; ?>" data-step="install-iframe">Install/Update iFrame Redirect</button> <span class="message"></span></li>

                            <li><button type="button" class="btn btn-xs btn-exec btn-info btn-confirm" data-step="remove-tmp-folder">Optional: Try to Remove tmp Folder</button> <span class="message"></span></li>

                            <?php $class = ($test['create-tmp-folder']) ? 'btn-success' : 'btn-primary'; ?>
                            <li><button type="button" class="btn btn-xs btn-exec <?php echo $class; ?>" data-step="create-tmp-folder">Create tmp Folder</button> <span class="message"></span></li>

                            <?php $class = ($test['change-tmp-folder-permission']) ? 'btn-success' : 'btn-primary'; ?>
                            <li><button type="button" class="btn btn-xs btn-exec <?php echo $class; ?>" data-step="change-tmp-folder-permission">Change tmp Folder Permission</button> <span class="message"></span></li>

                            <?php $class = ($test['setup-advanced-list-rule']) ? 'btn-success' : 'btn-primary'; ?>
                            <li>
                                <button type="button" class="btn btn-xs btn-exec <?php echo $class; ?>" data-step="setup-advanced-list-rule">Install/Update Advanced List Rule</button> <span class="message"></span>
                                <div>** Please install cron manually by ssh to this server as root and exec - <br><strong>(crontab -l; echo \"*/15 * * * * /usr/bin/php /srv/www/htdocs/x5/cron/admin_ajax.php >/dev/null 2>&1\") | crontab -u root -</strong></div>
                                <div>** To check if cron exists, ssh to this server and exec - <strong>crontab -u root -l | grep "admin_ajax.php"</strong></div>
                            </li>
                        </ul>
                    </fieldset>

                    <fieldset>
                        <legend>Optional Settings</legend>
                        <ul style="line-height: 30px;">
                            <?php $class = ($test['setup-max-allowed-login-user']) ? 'btn-success' : 'btn-warning'; ?>
                            <li>
                                <button type="button" class="btn btn-xs btn-exec <?php echo $class; ?> btn-confirm" data-step="setup-max-allowed-login-user">Enable/Disable Max Allowed Login User Setting</button> <span class="message"></span>
                                <ul id="max-allowed-login-user-section">
                                    <li><button type="button" class="btn btn-xs btn-exec btn-warning btn-confirm" data-step="setup-max-allowed-login-user-version-2">Enable Max Allowed Login User Setting (Version 2)</button> <span class="message"></span></li>
                                    <li><button type="button" class="btn btn-xs btn-exec btn-warning btn-confirm" data-step="setup-max-allowed-login-user-version-3">Enable Max Allowed Login User (Version 3 With Cluster Support)</button> <span class="message"></span></li>
                                    <li>Company ID: <input type="text" id="company_id" /> You need to set a company ID before syncing with Gumby</li>
                                    <li>Cluster ID: <input type="text" id="cluster_id" disabled="disabled" /></li>
                                    <li><button type="button" class="btn btn-xs btn-primary" id="update-max-allowed-login-setting" data-step="update-max-allowed-login-setting">Update Max Allowed Login User Setting</button> <span class="message"></span></li>
                                    <li>Max Allowed Login User: <input type="text" id="max_allowed_login_user" /> | Current DB Cached: <input type="text" id="max_allowed_login_user_cached" disabled /></li>
                                    <li>Max Allowed Login User (Outbound): <input type="text" id="max_allowed_login_user_outbound" /> | Current DB Cached: <input type="text" id="max_allowed_login_user_outbound_cached" disabled /></li>
                                    <li>Max Allowed Login User (Closer): <input type="text" id="max_allowed_login_user_closer" /> | Current DB Cached: <input type="text" id="max_allowed_login_user_closer_cached" disabled /></li>
                                    <li>Seat Count Live: <br> <textarea id="seat-count-from-myytel" style="width: 100%"></textarea></li>
                                    <li><button type="button" class="btn btn-xs btn-primary" id="set-max-allowed-login-user" data-step="set-max-allowed-login-user">Set Manual Max Allowed Login User</button> <span class="message"></span></li>
                                    <li>API Funded:
                                        <select id="api_funded"><option value="1">YES</option><option value="0">NO</option><option value="2">YES (LOCKED)</option><option value="-1">NO (LOCKED)</option></select>
                                        | Current DB Cached: <select id="api_funded_cached" disabled><option value="1">YES</option><option value="0">NO</option><option value="2">YES (LOCKED)</option><option value="-1">NO (LOCKED)</option></select></li>
                                    <li><button type="button" class="btn btn-xs btn-primary" id="set-max-allowed-login-user-api-funded" data-step="set-max-allowed-login-user-api-funded">Set API Funded</button> <span class="message"></span></li>
                                    <li><button type="button" class="btn btn-xs btn-exec btn-info" data-step="sync-max-allowed-login-user">Sync Max Allowed Login User Settings From Gumby</button> <span class="message"></span></li>
                                    <li>Max Allowed Login User Last Update: <input type="text" id="max_allowed_login_user_last_update" readonly /></li>
                                    <li>Max Allowed Login User Last Updated By: <input type="text" id="max_allowed_login_user_updated_by" readonly /></li>
                                    <li> Current Login Agent <button type="button" class="btn btn-xs btn-info" id="get-current-login-agent" data-step="get-current-login-agent">Get Current Login Agent</button>
                                        <ul>
                                            <li>Total: <input type="text" id="total_login_agent" readonly /></li>
                                            <li>Outbound: <input type="text" id="total_outbound_agent" readonly /></li>
                                            <li>Closer: <input type="text" id="total_closer_agent" readonly /></li>
                                        </ul>
                                    </li>
                                    <li>DISABLE
                                        <ul>
                                            <li><button type="button" class="btn btn-xs btn-exec btn-warning btn-confirm" data-step="disable-max-allowed-login-user">Disable ALL Max Allowed Login User</button> <span class="message"></span></li>
                                            <li><button type="button" class="btn btn-xs btn-exec btn-warning btn-confirm" data-step="disable-max-allowed-login-user-version-2">Disable Max Allowed Login User (Version 2 ana 3)</button> <span class="message"></span></li>
                                            <li><button type="button" class="btn btn-xs btn-exec btn-warning btn-confirm" data-step="disable-max-allowed-login-user-version-3">Disable Max Allowed Login User (Version 3 With Cluster Support)</button> <span class="message"></span></li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>

                            <li>
                                <?php $class = ($test['setup-chat']) ? 'btn-success' : 'btn-warning'; ?>
                                <button type="button" class="btn btn-xs btn-exec <?php echo $class; ?> btn-confirm" data-step="enable-chat">Enable/Disable V1 Chat Room</button> <span class="message"></span>

                                <ul id="chat-section">
                                    <li>Chat Room ID: <input type="text" id="chat_room_id" size="50" /> Refer to Openfile setup. Usually: chatlobby@conference.idxxxx.ytel.com</li>
                                    <li>Chat Room Server: <input type="text" id="chat_room_server" size="30" /> Ususally this server's domain name. <?php echo $_SERVER['HTTP_HOST']; ?></li>
                                    <li><button type="button" class="btn btn-xs btn-primary" id="update-chat-setting" data-step="update-chat-setting">Update Chat Setting</button> <span class="message"></span></li>
                                    <li><button type="button" class="btn btn-xs btn-exec btn-info btn-confirm" data-step="disable-chat">Disable Chat</button> <span class="message"></span></li>
                                </ul>
                            </li>

                            <li>
<!--                                --><?php //$class = ($test['setup-chat-2']) ? 'btn-success' : 'btn-warning'; ?>
                                <button type="button" class="btn btn-xs btn-exec" disabled data-step="enable-chat-2">Enable/Disable Ytel Chat</button> <span class="message"></span>

                                <ul id="chat-2-section">
                                    <li>X5 Domain: <input type="text" id="x5_domain" value="<?php echo $test['x5:domain']; ?>" size="50"></li>
                                    <li>Database: <input type="text" id="chat2_database" value="<?php echo $test['chat2:database']; ?>" size="50"></li>
                                    <li><button type="button" class="btn btn-xs btn-primary" id="update-chat-2-setting" data-step="update-chat-2-setting">Update Chat Setting</button> <span class="message"></span></li>
                                    <li><button type="button" class="btn btn-xs btn-exec btn-info btn-confirm" data-step="disable-chat-2">Disable Chat</button> <span class="message"></span></li>
                                </ul>
                            </li>

                            <li>
                                <?php $class = ''; ?>
                                <button type="button" class="btn btn-xs btn-exec <?php echo $class; ?> btn-confirm" data-step="leadbeam-setup">Build Leadbeam Database</button> <span class="message"></span></li>
                            </li>

                            <li>
                                <?php $class = ($test['x5-theme']) ? 'btn-success' : 'btn-warning'; ?>
                                <button type="button" class="btn btn-xs btn-exec <?php echo $class; ?> btn-confirm" data-step="enable-x5-prime">Enable/Disable X5 Prime</button> <span class="message"></span>

                                <ul id="x5-theme-section">
                                    <li><button type="button" class="btn btn-xs btn-exec btn-info btn-confirm" data-step="disable-x5-prime">Disable X5 Prime</button> <span class="message"></span></li>
                                </ul>
                            </li>
                        </ul>
                    </fieldset>

                    <div>
                        <h4>Note:</h4>
                        <h4><span class="label label-success">Installed or Up-to-Day or Enabled</span> <span class="label label-warning">Disable or Disabled</span> <span class="label label-primary">Need to install or update</span> <span class="label label-info">Optional steps</span> <span class="label label-danger">Error</span></h4>
                    </div>
                </div>
            </div>

            <div class="well well-lg">
                <h4>Commit Log (Last 10)</h4>
                <?php echo str_replace("\n", "<br>", shell_exec("git log -10 --date=local --pretty=format:'%h - %s (%ci)' --abbrev-commit")); ?>
            </div>
        </div>

        <script>
            var btn_danger = 0;
            var btn_success = 1;
            var btn_primary = 2;
            var btn_warning = 3;
            var seat_count_version_1 = 4;
            var seat_count_version_2 = 6;
            var seat_count_version_3 = 7;

            var max_allowed_login_user = <?php if( $test['setup-max-allowed-login-user'] ) echo "true"; else echo "false"; ?>;
            var max_allowed_login_user_version_2 = <?php if( $test['setup-max-allowed-login-user-version-2'] ) echo "true"; else echo "false"; ?>;
            var max_allowed_login_user_version_3 = <?php if( $test['setup-max-allowed-login-user-version-3'] ) echo "true"; else echo "false"; ?>;
            var chat = <?php if( $test['setup-chat'] ) echo "true"; else echo "false"; ?>;
            var x5_theme = <?php if($test['x5-theme']) echo "true"; else echo "false"; ?>;

            $(document).ready(function() {
                $("#main-control").on("click", "button.btn-exec", function(){
                    exec($(this));
                });

                if( max_allowed_login_user || max_allowed_login_user_version_2 || max_allowed_login_user_version_3 )
                {


                    get_max_allowed_login_user_settings();
                }

                if( max_allowed_login_user_version_2 || max_allowed_login_user_version_3 )
                {
                    $("button[data-step='setup-max-allowed-login-user-version-2']").removeClass("btn-exec");
                }

                $("#update-max-allowed-login-setting, #set-max-allowed-login-user").click(function() {
                    var $btn = $(this);
                    var $message = $btn.siblings(".message");

                    $.ajax({
                        url: './index.php',
                        type: 'post',
                        data: {
                            action: $btn.data("step"),
                            key: '<?php echo $_REQUEST['key']; ?>',
                            max_allowed_login_user: $("#max_allowed_login_user").val(),
                            max_allowed_login_user_outbound: $("#max_allowed_login_user_outbound").val(),
                            max_allowed_login_user_closer: $("#max_allowed_login_user_closer").val(),
                            api_funded: $("#api_funded").val(),
                            company_id: $("#company_id").val(),
                            cluster_id: $("#cluster_id").val()
                        },
                        dataType: 'json',
                        success: function(json) {
                            change_btn_status($btn, json.status);

                            if (json.status == 0)
                            {
                                $message.html("Line " + json.line + ": " + json.message);
                            }
                            else
                            {
                                $message.html(json.message);
                            }

                            get_max_allowed_login_user_settings();
                        },
                        error: function() {
                            change_btn_status($btn, 0);
                            $message.html("Something went wrong, please do that manually.");

                            get_max_allowed_login_user_settings();
                        }
                    });
                });

                $("#set-max-allowed-login-user-api-funded").click(function() {
                    var $btn = $(this);
                    var $message = $btn.siblings(".message");

                    $.ajax({
                      url: './index.php',
                      type: 'post',
                      data: {
                        action: $btn.data("step"),
                        key: '<?php echo $_REQUEST['key']; ?>',
                        api_funded: $("#api_funded").val(),
                        company_id: $("#company_id").val(),
                        cluster_id: $("#cluster_id").val()
                      },
                      dataType: 'json',
                      success: function(json) {
                        change_btn_status($btn, json.status);

                        if (json.status == 0)
                        {
                          $message.html("Line " + json.line + ": " + json.message);
                        }
                        else
                        {
                          $message.html(json.message);
                        }

                        get_max_allowed_login_user_settings();
                      },
                      error: function() {
                        change_btn_status($btn, 0);
                        $message.html("Something went wrong, please do that manually.");

                        get_max_allowed_login_user_settings();
                      }
                    });
                });

                if( chat )
                {
                    $("#chat-section").slideDown();

                    $("button[data-step='enable-chat']").removeClass("btn-exec");

                    get_chat_settings();
                }

                $("#update-chat-setting").click(function() {
                    var $btn = $(this);
                    var $message = $btn.siblings(".message");

                    $.ajax({
                        url: './index.php',
                        type: 'post',
                        data: {action: $btn.data("step"), key: '<?php echo $_REQUEST['key']; ?>', chat_room_id: $("#chat_room_id").val(), chat_room_server: $("#chat_room_server").val()},
                        dataType: 'json',
                        success: function(json) {
                            change_btn_status($btn, json.status);

                            if (json.status == 0)
                            {
                                $message.html("Line " + json.line + ": " + json.message);
                            }
                            else
                            {
                                $message.html(json.message);
                            }

                            get_chat_settings();
                        },
                        error: function() {
                            change_btn_status($btn, 0);
                            $message.html("Something went wrong, please do that manually.");

                            get_chat_settings();
                        }
                    });
                });

                $("#update-chat-2-setting").click(function() {
                    var $btn = $(this);
                    var $message = $btn.siblings(".message");

                    $.ajax({
                        url: './index.php',
                        type: 'post',
                        data: {action: $btn.data("step"), key: '<?php echo $_REQUEST['key']; ?>', x5_domain: $("#x5_domain").val(), chat2_database: $("#chat2_database").val()},
                        dataType: 'json',
                        success: function(json) {
                            change_btn_status($btn, json.status);

                            if (json.status == 0)
                            {
                                $message.html("Line " + json.line + ": " + json.message);
                            }
                            else
                            {
                                $message.html(json.message);
                            }

                            // get_chat_settings();
                        },
                        error: function() {
                            change_btn_status($btn, 0);
                            $message.html("Something went wrong, please do that manually.");

                            // get_chat_settings();
                        }
                    });
                });

                $("#get-current-login-agent").click(function() {
                    var $btn = $(this);
                    var $message = $btn.siblings(".message");

                    $.ajax({
                        url: './index.php',
                        type: 'get',
                        data: {action: $btn.data("step"), key: '<?php echo $_REQUEST['key']; ?>'},
                        dataType: 'json',
                        success: function(json) {
                            change_btn_status($btn, json.status);

                            if (json.status == 0)
                            {
                                $message.html("Line " + json.line + ": " + json.message);
                            }
                            else
                            {
                                $.each(json.output, function(key, value) {
                                    $("#"+key).val(value);
                                });
                            }
                        },
                        error: function() {
                            change_btn_status($btn, 0);
                            $message.html("Something went wrong");
                        }
                    });
                });

                if( x5_theme )
                {
                    $("#x5-theme-section").slideDown();

                    $("button[data-step='enable-x5-theme']").removeClass("btn-exec");

//                    get__settings();
                }

            });

            function exec($btn)
            {
                var $message = $btn.siblings(".message");

                if( $btn.hasClass("btn-confirm") && !confirm("Do you want to proceed?") )
                {
                    return;
                }

                $.ajax({
                    url: './index.php',
                    type: 'post',
                    data: {action: $btn.data("step"), key: '<?php echo $_REQUEST['key']; ?>'},
                    dataType: 'json',
                    success: function(json) {
                        change_btn_status($btn, json.status);
                        console.log(json);
                        if (json.status == 0)
                        {
                            $message.html("Line " + json.line + ": " + json.message);
                        }
                        else
                        {
                            $message.html(json.message);

                            switch( $btn.data("step") )
                            {
                                case 'setup-max-allowed-login-user':
                                    get_max_allowed_login_user_settings();
                                    break;

                                case 'setup-max-allowed-login-user-version-2':
                                    get_max_allowed_login_user_settings();
                                    break;

                                case 'setup-max-allowed-login-user-version-3':
                                    get_max_allowed_login_user_settings();
                                    break;

                                case 'disable-max-allowed-login-user':
                                    get_max_allowed_login_user_settings();
                                    break;

                                case 'disable-max-allowed-login-user-version-2':
                                    get_max_allowed_login_user_settings();
                                    break;

                                case 'disable-max-allowed-login-user-version-3':
                                    get_max_allowed_login_user_settings();
                                    break;

                                case 'sync-max-allowed-login-user':
                                    get_max_allowed_login_user_settings();
                                    break;

                                case 'enable-chat':
                                    $("#chat-section").slideDown();
                                    change_btn_status($("button[data-step='enable-chat']"), 3);
                                    break;

                                case 'disable-chat':
                                    $("#chat-section").slideUp();
                                    change_btn_status($("button[data-step='enable-chat']"), 3);
                                    break;

                                case 'enable-x5-theme':
                                    $("#chat-section").slideDown();
                                    change_btn_status($("button[data-step='enable-x5-theme']"), 3);
                                    break;

                                case 'disable-x5-theme':
                                    $("#chat-section").slideUp();
                                    change_btn_status($("button[data-step='enable-x5-theme']"), 3);
                                    break;
                            }
                        }
                    },
                    error: function() {
                        change_btn_status($btn, 0);
                        $message.html("Something went wrong, please do that manually.");
                    }
                });
            }

            function get_max_allowed_login_user_settings()
            {
                $.ajax({
                    url: './index.php',
                    type: 'get',
                    data: {action: 'get-max-allowed-login-user-settings', key: '<?php echo $_REQUEST['key']; ?>'},
                    dataType: 'json',
                    success: function(json) {
                        // Seat count enabled
                        if(json.output['seat_count_version'] !== false)
                        {
                          $.ajax({
                            url: './index.php',
                            type: 'get',
                            data: {
                              action: 'get-max-allowed-login-user-settings-myytel',
                              key: '<?php echo $_REQUEST['key']; ?>'
                            },
                            dataType: 'json',
                            success: function (json) {
                                $("#seat-count-from-myytel").val(JSON.stringify(json.output));
                            }
                          });


                            $("#max-allowed-login-user-section").slideDown();

                            change_btn_status($("button[data-step='setup-max-allowed-login-user']"), btn_success, true, false);

                            if(json.output['seat_count_version'] === seat_count_version_1)
                            {
                                // Seat count version 1

                                json.output['cluster_id'] = 'Not Enabled';
                                json.output['max_allowed_login_user_outbound'] = 'Not Using';
                                json.output['max_allowed_login_user_closer'] = 'Not Using';

                                $("#cluster_id").attr('disabled', true);
                                $("#max_allowed_login_user").attr("disabled", false);
                                $("#max_allowed_login_user_outbound").attr("disabled", true);
                                $("#max_allowed_login_user_closer").attr("disabled", true);


                                change_btn_status($("button[data-step='setup-max-allowed-login-user-version-2']"), btn_warning, false, true);
                                change_btn_status($("button[data-step='setup-max-allowed-login-user-version-3']"), btn_warning, true, false);
                            } else if(json.output['seat_count_version'] === seat_count_version_2)
                            {
                                // Seat count version 2

                                json.output['cluster_id'] = 'Not Enabled';
                                json.output['max_allowed_login_user'] = 'Not Using';

                                $("#cluster_id").attr('disabled', true);
                                $("#max_allowed_login_user").attr("disabled", true);
                                $("#max_allowed_login_user_outbound").attr("disabled", false);
                                $("#max_allowed_login_user_closer").attr("disabled", false);

                                change_btn_status($("button[data-step='setup-max-allowed-login-user-version-2']"), btn_success, true, false);
                                change_btn_status($("button[data-step='setup-max-allowed-login-user-version-3']"), btn_warning, false, true);
                            } else if(json.output['seat_count_version'] === seat_count_version_3)
                            {
                                // Seat count version 3

                                json.output['max_allowed_login_user'] = 'Not Using';

                                $("#cluster_id").attr('disabled', false);
                                $("#max_allowed_login_user").attr("disabled", true);
                                $("#max_allowed_login_user_outbound").attr("disabled", false);
                                $("#max_allowed_login_user_closer").attr("disabled", false);

                                change_btn_status($("button[data-step='setup-max-allowed-login-user-version-2']"), btn_success, true, false);
                                change_btn_status($("button[data-step='setup-max-allowed-login-user-version-3']"), btn_success, true, false);
                            }

                            $.each(json.output, function(key, value) {
                                $("#"+key+",#"+key+"_cached").val(value);
                            });
                        } else {
                            $("#max-allowed-login-user-section").slideDown();

                            change_btn_status($("button[data-step='setup-max-allowed-login-user']"), btn_warning, false, true);
                        }


                    },
                    error: function(json) {
                        console.error(json)
                    }
                });
            }

            function get_chat_settings()
            {
                $.ajax({
                    url: './index.php',
                    type: 'get',
                    data: {action: 'get-chat-settings', key: '<?php echo $_REQUEST['key']; ?>'},
                    dataType: 'json',
                    success: function(json) {
                        console.log(json);
                        $.each(json.output, function(key, value) {
                            $("#"+key).val(value);
                            if( value == null )
                                change_btn_status($("button[data-step='enable-chat']"), 3);
                        });
                    },
                    error: function() {
                    }
                });
            }

            function change_btn_status($btn, status_code, disable, allowExec)
            {
                if(typeof disable === 'undefined') {
                    disable = false;
                }

                if(typeof allowExec !== 'undefined') {
                    if(allowExec) {
                        $btn.addClass('btn-exec');
                    } else {
                        $btn.removeClass('btn-exec');
                    }
                }

                $btn.removeClass("btn-primary btn-warning btn-info btn-success btn-danger");

                switch (status_code)
                {
                    case btn_danger:
                        $btn.addClass("btn-danger");
                        break;

                    case btn_success:
                        $btn.addClass("btn-success");
                        break;

                    case btn_primary:
                        $btn.addClass("btn-primary");
                        break;

                    case btn_warning:
                        $btn.addClass("btn-warning");
                        break;
                }

                if(disable) {
                    $btn.attr('disabled', true);
                } else {
                    $btn.attr("disabled", false);
                }

            }
        </script>
    </body>
</html>
