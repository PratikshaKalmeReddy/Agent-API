<?php
    /*
         * Copyright 2019 Ytel, Inc <support@ytel.com>.
         *
         * Ytel, Inc. CONFIDENTIAL
         * ----------------------------------
         * Ytel, Inc.
         * All Rights Reserved.
         * NOTICE:  All information contained herein is, and remains
         * the property of Ytel, Inc. and its suppliers, if any.
         * The intellectual and technical concepts contained
         * herein are proprietary to Ytel, Inc. and its suppliers and may
         * be covered by U.S. and Foreign Patents, patents in process, and
         * are protected by trade secret or copyright law.
         * Dissemination of this information or reproduction of this material
         * is strictly forbidden unless prior written permission is obtained
         * from Ytel, Inc.
         *
         * User: sunny
         * Date: 10/23/19
         * Time: 11:52
     */

    class YtelSeatCount {
        const YTEL_SEAT_COUNT_API_KEY = 'Yt65NPlBmLQREaDKiMVr';
        const MYYTEL_SEAT_COUNT_TOKEN = 'UqKmZUuLTXu2J7w5Fa0Et6O8TaHVCRsC8GYftg2t';
        const MYYTEL_SEAT_COUNT_API = 'https://my.ytel.com/Api/getMaxAllowedLoginUserSetting.json';
        const MYYTEL_SEAT_COUNT_SET_MANUAL_API = 'https://my.ytel.com/Api/setManualSeatCount.json';
//        const MYYTEL_SEAT_COUNT_ERROR_NOTIFICATION_URL = 'https://3b5c8c01619f9cbb225a22103d2b6c7c.m.pipedream.net';
        const MYYTEL_SEAT_COUNT_ERROR_METRIC_API = 'https://us-central1-ytel-systems.cloudfunctions.net/yccMyytelConnectionIssue';
//        const SEAT_COUNT_METRIC_URL = 'https://3b5c8c01619f9cbb225a22103d2b6c7c.m.pipedream.net';
        const SEAT_COUNT_METRIC_API = 'https://us-central1-ytel-systems.cloudfunctions.net/yccLiveLoginAgent';

        const SEAT_COUNT_VERSION_1 = 4;
        const SEAT_COUNT_VERSION_2 = 6;
        const SEAT_COUNT_VERSION_3 = 7;

        private $dbLink;
        private $install = false;
        private $adminClientId;
        private $adminAccountSid;
        private $currentSeatCountVersion;
        private $currentSeatCountSettings;

        public function getClientIP()
        {
            $ipaddress = 'UNKNOWN';
            $keys=array('HTTP_CLIENT_IP','HTTP_X_FORWARDED_FOR','HTTP_X_FORWARDED','HTTP_FORWARDED_FOR','HTTP_FORWARDED','REMOTE_ADDR');
            foreach($keys as $k)
            {
                if (isset($_SERVER[$k]) && !empty($_SERVER[$k]) && filter_var($_SERVER[$k], FILTER_VALIDATE_IP))
                {
                    $ipaddress = $_SERVER[$k];
                    break;
                }
            }
            return $ipaddress;
        }

        /**
         * YtelSeatCount constructor.
         *
         * @param      $dbLink
         * @param bool $install
         *
         * @throws Exception
         */
        public function __construct($dbLink, $install = false, $adminClientId = null, $adminAccountSid = null) {
            if(!$dbLink) {
                throw new Exception('Missing DB Link');
            }

            $this->dbLink = $dbLink;
            $this->install = $install;
            $this->adminClientId = $adminClientId;
            $this->adminAccountSid = $adminAccountSid;
        }

        public static function isApiFunded($apiFunded) {
            switch($apiFunded) {
                case -1:
                case 0:
                    return false;

                    // 1, 2
                default:
                    return true;
            }
        }

        /**
         * Get the system seat count version by checking system_settings fields
         *
         * @return bool|false|int
         * @throws Exception
         */
        public function getSeatCountVersion() {
            try {
                if($this->currentSeatCountVersion) {
                    return $this->currentSeatCountVersion;
                }

                $query = "SHOW columns FROM system_settings where Field IN ('max_allowed_login_user', 'company_id', 'cluster_id', 'max_allowed_login_user_last_update', 'max_allowed_login_user_updated_by', 'max_allowed_login_user_outbound', 'max_allowed_login_user_closer')";
                $result = mysqli_query($this->dbLink, $query);
                if(mysqli_errno($this->dbLink))
                    throw new Exception("Cannot get required col for max allowed login user version. Error: " . mysqli_error($this->dbLink) . " Query: " . $query);

                $this->currentSeatCountVersion = mysqli_num_rows($result);

                return $this->currentSeatCountVersion;

            } catch(Exception $ex) {
                if($this->install) {
                    throw $ex;
                } else {
                    return false;
                }
            }
        }

        /**
         * Get the seat count settings (company_id and cluster_id)
         *
         * @return array|bool
         * @throws Exception
         */
        public function getSeatCountSettings() {
            try {
                if($this->currentSeatCountSettings) {
                    return $this->currentSeatCountSettings;
                }

                $colCount = $this->getSeatCountVersion();

                if( $colCount == self::SEAT_COUNT_VERSION_1 || $colCount == self::SEAT_COUNT_VERSION_2 ) {
                    $query = "SELECT company_id FROM system_settings LIMIT 1";
                    $result = mysqli_query($this->dbLink, $query);
                    if(mysqli_errno($this->dbLink))
                        throw new Exception("Cannot get company id. Error: " . mysqli_error($this->dbLink) . " Query: " . $query);
                    $output = mysqli_fetch_assoc($result);
                    $company_id = $output['company_id'];
                    $cluster_id = 0;
                } else if( $colCount == self::SEAT_COUNT_VERSION_3 ) {
                    $query = "SELECT company_id, cluster_id FROM system_settings LIMIT 1";
                    $result = mysqli_query($this->dbLink, $query);
                    if(mysqli_errno($this->dbLink))
                        throw new Exception("Cannot get company id and cluster id. Error: " . mysqli_error($this->dbLink) . " Query: " . $query);
                    $output = mysqli_fetch_assoc($result);
                    $company_id = $output['company_id'];
                    $cluster_id = $output['cluster_id'];
                }

                $this->currentSeatCountSettings = array(
                    'company_id' => $company_id,
                    'cluster_id' => $cluster_id,
                );

                return $this->currentSeatCountSettings;
            } catch(Exception $ex) {
                if($this->install) {
                    throw $ex;
                } else {
                    return false;
                }
            }
        }

        /**
         * Get seat count from my.ytel
         *
         * @param int|null $currentLoginAgent
         *
         * @return mixed|string
         * @throws Exception
         */
        public function getSeatCountFromMyYtel($currentLoginAgent = null, $agentId = null) {
            try {
                $seatCountSettings = $this->getSeatCountSettings();
                if(!$seatCountSettings) {
                    throw new Exception('Cannot get seat count');
                }

                if(!$currentLoginAgent) {
                    $payload = (
                        array(
                            'token' => self::YTEL_SEAT_COUNT_API_KEY,
                            'company_id' => $seatCountSettings['company_id'],
                            'cluster_id' => $seatCountSettings['cluster_id'],
                        )
                    );
                } else {
                    $payload = (
                        array(
                            'token' => self::YTEL_SEAT_COUNT_API_KEY,
                            'company_id' => $seatCountSettings['company_id'],
                            'cluster_id' => $seatCountSettings['cluster_id'],
                            'current_login_agent' => $currentLoginAgent,
//                            'debug_delay' => 5,
                        )
                    );
                }

                $i = 0;
                do
                {
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, self::MYYTEL_SEAT_COUNT_API);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                    $data = curl_exec($ch);
                    curl_close($ch);
                    $i++;

                    if( $i == 2 && $data == '' )
                    {
                        $this->notifyConnectToMyYtelIssue($agentId);
                        throw new Exception("Cannot connect to my.ytel please try again later.");
                    }

                    if($data == '') {
                        sleep(1);
                    }
                }while( $data == '' );

                $jsonData = json_decode($data);

                if(json_last_error() !== JSON_ERROR_NONE) {
                    throw new Exception(json_last_error());
                }

                if(empty($jsonData->status)) {
                    return false;
                }

                $_SESSION['seatCountFromMyytel'] = $jsonData;

                return $jsonData;
            } catch(Exception $ex) {
                if($this->install) {
                    throw $ex;
                } else {
                    return false;
                }
            }
        }

        /**
         * Get seat count from local DB
         *
         * @return array|bool
         * @throws Exception
         */
        public function getSeatCount() {
            try {
                $colCount = $this->getSeatCountVersion();
                if( $colCount == self::SEAT_COUNT_VERSION_1 )
                {
                    $query = "SELECT api_funded, max_allowed_login_user, company_id, max_allowed_login_user_last_update, max_allowed_login_user_updated_by FROM system_settings LIMIT 1";
                    $result = mysqli_query($this->dbLink, $query);
                    if(mysqli_errno($this->dbLink))
                        throw new Exception("Error getting max allowed user settings. Error: " . mysqli_error($this->dbLink) . " Query: " . $query);
                    $output = mysqli_fetch_assoc($result);
                } else if( $colCount == self::SEAT_COUNT_VERSION_2 ) {
                    $query = "SELECT api_funded, max_allowed_login_user, max_allowed_login_user_outbound, max_allowed_login_user_closer, company_id, max_allowed_login_user_last_update, max_allowed_login_user_updated_by FROM system_settings LIMIT 1";
                    $result = mysqli_query($this->dbLink, $query);
                    if(mysqli_errno($this->dbLink))
                        throw new Exception("Error getting max allowed user settings. Error: " . mysqli_error($this->dbLink) . " Query: " . $query);
                    $output = mysqli_fetch_assoc($result);
                } else if( $colCount == self::SEAT_COUNT_VERSION_3 ) {
                    $query = "SELECT api_funded, max_allowed_login_user, max_allowed_login_user_outbound, max_allowed_login_user_closer, company_id, cluster_id, max_allowed_login_user_last_update, max_allowed_login_user_updated_by FROM system_settings LIMIT 1";
                    $result = mysqli_query($this->dbLink, $query);
                    if(mysqli_errno($this->dbLink))
                        throw new Exception("Error getting max allowed user settings. Error: " . mysqli_error($this->dbLink) . " Query: " . $query);
                    $output = mysqli_fetch_assoc($result);
                } else {
                    return false;
                }

                return $output;
            } catch(Exception $ex) {
                if($this->install) {
                    throw $ex;
                } else {
                    return array();
                }
            }
        }


        /**
         * Get the current seat count use cache if needed
         * @param null $currentLoginAgent
         */
        public function getSeatCountCached($currentLoginAgent = null, $agentId = null)
        {
            // Get seat count and funded cached from the DB
            $seatCountCached = $seatCount = $this->getSeatCount();

            // Check if there is data from
            if(isset($seatCount['max_allowed_login_user_last_update'])) {
                // Check my.ytel every 30s only
                if(strtotime($seatCount['max_allowed_login_user_last_update']) + 30 < time()) {
                    // Get seat count and funded from my.ytel
                    $seatCountFromMyYtel = $this->getSeatCountFromMyYtel($currentLoginAgent, $agentId);

                    // See if we can get data from my.ytel
                    if($seatCountFromMyYtel === false || !(isset($seatCountFromMyYtel->status) && $seatCountFromMyYtel->status == 1)) {
                        // Set last update to now, so it will skip checking for another 30 seconds
                        $query = "UPDATE system_settings SET max_allowed_login_user_last_update = NOW()";
                        mysqli_query($this->dbLink, $query);

                        // If not just return the cached data
                        return $seatCount;
                    }

                    // Check if we need to update api funded
                    if(!is_null($seatCount['api_funded'])) {
                        $seatCount['api_funded'] = (int) $seatCount['api_funded'];

                        if($seatCount['api_funded'] === 0 || $seatCount['api_funded'] === 1) {
                            // Use data from my.ytel
                            $seatCount['api_funded'] = isset($seatCountFromMyYtel->api_funded) ? $seatCountFromMyYtel->api_funded : $seatCountCached['api_funded'];
                        }
                    } else {
                        // Use my.ytel data (0 if no data from my.ytel)
                        $seatCount['api_funded'] = isset($seatCountFromMyYtel->api_funded) && $seatCountFromMyYtel->api_funded ? 1 : 0;
                    }

                    $seatCount['api_funded'] = (int) $seatCount['api_funded'];

                    // Check if we need to turn outbound on or off
                    if($seatCountCached['api_funded'] != $seatCount['api_funded']) {
                        if(self::isApiFunded($seatCount['api_funded'])) {
                            $this->turnOnOutbound();
                        } else {
                            $this->turnOffOutbound();
                        }
                    }

                    // See if we need to update seat number
                    if ($seatCount['max_allowed_login_user_updated_by'] == 'my.ytel') {
                        // Use the updated data from gumby
                        $seatCount['max_allowed_login_user_outbound'] = !empty($seatCountFromMyYtel->max_outbound) ? $seatCountFromMyYtel->max_outbound : 0;
                        $seatCount['max_allowed_login_user_closer'] = !empty($seatCountFromMyYtel->max_closer) ? $seatCountFromMyYtel->max_closer : 0;

                        $query = "UPDATE system_settings SET api_funded = {$seatCount['api_funded']}, max_allowed_login_user_outbound = {$seatCount['max_allowed_login_user_outbound']}, max_allowed_login_user_closer = {$seatCount['max_allowed_login_user_closer']}, max_allowed_login_user_last_update = NOW()";
                        mysqli_query($this->dbLink, $query);
                    } else {
                        // Set api funded only
                        $query = "UPDATE system_settings SET api_funded = {$seatCount['api_funded']}, max_allowed_login_user_last_update = NOW()";
                        mysqli_query($this->dbLink, $query);
                    }
                }
            }

            return $seatCount;
        }



        public function notifyUpdateManualSeatCount($maxOutbound, $maxCloser, $by = 'X5 Installer')
        {
            $seatCountSettings = $this->getSeatCountSettings();

            $payload = (
                array(
                    'token' => self::MYYTEL_SEAT_COUNT_TOKEN,
                    'company_id' => $seatCountSettings['company_id'],
                    'cluster_id' => $seatCountSettings['cluster_id'],
                    'max_outbound' => $maxOutbound,
                    'max_closer' => $maxCloser,
                    'manual_by' => $by,
                    'requester_ip' => $this->getClientIP(),
                    'server_name' => $_SERVER['SERVER_NAME'],
                    'http_host' => $_SERVER['HTTP_HOST'],
                    'admin_client_id' => $this->adminClientId,
                    'admin_account_sid' => $this->adminAccountSid,
                )
            );

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, self::MYYTEL_SEAT_COUNT_SET_MANUAL_API);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            $output = curl_exec($ch);
            curl_close($ch);

            return $output;
        }

        public function notifyDisableSeatCount($version)
        {
            return $this->notifyUpdateManualSeatCount(-3, $version);
        }

        public function notifyEnableSeatCount($version)
        {
            return $this->notifyUpdateManualSeatCount(-4, $version);
        }

        public function notifyConnectToMyYtelIssue($agentId = null)
        {
            try {
                if(!empty($_SERVER['HTTP_HOST'])) {
                    $domain = $_SERVER['HTTP_HOST'];
                } elseif(!empty($_SERVER['SERVER_NAME'])) {
                    $domain = $_SERVER['SERVER_NAME'];
                } else {
                    $domain = 'unknown';
                }

                $serverIp = $_SERVER['SERVER_ADDR'];
                $clientIp = $this->getClientIP();

                $payload = [
                    'domain' => $domain,
                    'serverIp' => $serverIp,
                    'agentIp' => $clientIp,
                    'agentId' => $agentId,
                ];

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, self::MYYTEL_SEAT_COUNT_ERROR_METRIC_API);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                curl_setopt($ch, CURLOPT_TIMEOUT, 1); //HERE MAGIC (We wait only 1ms on connection) Script waiting but (processing of send package to $curl is continue up to successful) so after 1ms we continue scripting and in background php continue already package to destiny. This is like apple on tree, we cut and go, but apple still fallow to destiny but we don't care what happened when fall down :)
                curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
                curl_exec($ch);
//                curl_close($ch);
            } catch( Exception $ex ) {
                return false;
            }
        }

        public function notifyLoginAgentCount($currentLoginAgent, $maxSeatCount)
        {
            try {
                if(!$currentLoginAgent) {
                    return false;
                }

                if(!empty($_SERVER['HTTP_HOST'])) {
                    $domain = $_SERVER['HTTP_HOST'];
                } elseif(!empty($_SERVER['SERVER_NAME'])) {
                    $domain = $_SERVER['SERVER_NAME'];
                } else {
                    return false;
                }

                $serverIp = $_SERVER['SERVER_ADDR'];
                $clientIp = $this->getClientIP();

                $payload = http_build_query([
                    'domain' => $domain,
                    'serverIp' => $serverIp,
                    'agentIp' => $clientIp,
                    'currentLoginAgent' => $currentLoginAgent,
                    'maxSeatCount' => $maxSeatCount,
                ]);

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, self::SEAT_COUNT_METRIC_API);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
                curl_setopt($ch, CURLOPT_TIMEOUT, 1); //HERE MAGIC (We wait only 1ms on connection) Script waiting but (processing of send package to $curl is continue up to successful) so after 1ms we continue scripting and in background php continue already package to destiny. This is like apple on tree, we cut and go, but apple still fallow to destiny but we don't care what happened when fall down :)
                curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
                curl_exec($ch);
//                curl_close($ch);
            } catch( Exception $ex ) {
                return false;
            }
        }

        public function turnOnOutbound()
        {
            $query = sprintf("UPDATE system_settings SET outbound_autodial_active = '%s'", '1');
            mysqli_query($this->dbLink, $query);

            if($this->install)
                if(mysqli_errno($this->dbLink))
                    throw new Exception("Cannot update system_settings. Error: " . mysqli_error($this->dbLink) . " Query: " . $query);
        }

        public function turnOffOutbound()
        {
            $query = sprintf("UPDATE system_settings SET outbound_autodial_active = '%s'", '0');
            mysqli_query($this->dbLink, $query);

            if($this->install)
                if(mysqli_errno($this->dbLink))
                    throw new Exception("Cannot update system_settings. Error: " . mysqli_error($this->dbLink) . " Query: " . $query);
        }
    }
