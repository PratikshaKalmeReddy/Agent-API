<?php

if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();}

$DBCagc = file("/etc/astguiclient.conf");
foreach ($DBCagc as $DBCline)
{
    $DBCline = preg_replace("/ |>|\n|\r|\t|\#.*|;.*/", "", $DBCline);
    if (preg_match("/^PATHlogs/", $DBCline))
    {
        $PATHlogs = $DBCline;
        $PATHlogs = preg_replace("/.*=/", "", $PATHlogs);
    }
    if (preg_match("/^PATHweb/", $DBCline))
    {
        $WeBServeRRooT = $DBCline;
        $WeBServeRRooT = preg_replace("/.*=/", "", $WeBServeRRooT);
    }
    if (preg_match("/^VARserver_ip/", $DBCline))
    {
        $WEBserver_ip = $DBCline;
        $WEBserver_ip = preg_replace("/.*=/", "", $WEBserver_ip);
    }
    if (preg_match("/^VARDB_server/", $DBCline))
    {
        $VARDB_server = $DBCline;
        $VARDB_server = preg_replace("/.*=/", "", $VARDB_server);
    }
    if (preg_match("/^VARDB_database/", $DBCline))
    {
        $VARDB_database = $DBCline;
        $VARDB_database = preg_replace("/.*=/", "", $VARDB_database);
    }
    if (preg_match("/^VARDB_user/", $DBCline))
    {
        $VARDB_user = $DBCline;
        $VARDB_user = preg_replace("/.*=/", "", $VARDB_user);
    }
    if (preg_match("/^VARDB_pass/", $DBCline))
    {
        $VARDB_pass = $DBCline;
        $VARDB_pass = preg_replace("/.*=/", "", $VARDB_pass);
    }
    if (preg_match("/^VARDB_port/", $DBCline))
    {
        $VARDB_port = $DBCline;
        $VARDB_port = preg_replace("/.*=/", "", $VARDB_port);
    }

    if (preg_match("/^VARDB_custom_user/", $DBCline))
    {
        $VARDB_custom_user = $DBCline;
        $VARDB_custom_user = preg_replace("/.*=/", "", $VARDB_custom_user);
    }
    if (preg_match("/^VARDB_custom_pass/", $DBCline))
    {
        $VARDB_custom_pass = $DBCline;
        $VARDB_custom_pass = preg_replace("/.*=/", "", $VARDB_custom_pass);
    }
}

$link = mysqli_connect("$VARDB_server:$VARDB_port", $VARDB_user, $VARDB_pass, $VARDB_database);
if (!$link)
{
    die('MySQL connect ERROR: ' . mysqli_error());
}
mysqli_select_db($link, $VARDB_database);

$link_custom = mysqli_connect("$VARDB_server:$VARDB_port", $VARDB_custom_user, $VARDB_custom_pass, $VARDB_database);
if (!$link_custom)
{
    die('MySQL connect ERROR: ' . mysqli_error());
}