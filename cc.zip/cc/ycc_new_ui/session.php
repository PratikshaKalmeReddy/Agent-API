<?php
    /*
         * Copyright 2024 Ytel, Inc <support@ytel.com>.
         *
         * Ytel, Inc. CONFIDENTIAL
         * ----------------------------------
         * Ytel, Inc.
         * All Rights Reserved.
         * NOTICE:  All information contained herein is, and remains
         * the property of Ytel, Inc. and its suppliers, if any. 
         * The intellectual and technical concepts contained
         * herein are proprietary to Ytel, Inc. and its suppliers and may
         * be covered by U.S. and Foreign Patents, patents in process, and 
         * are protected by trade secret or copyright law.
         * Dissemination of this information or reproduction of this material
         * is strictly forbidden unless prior written permission is obtained
         * from Ytel, Inc.
         *
         * User: Balaji
         * Date: 2/6/2024
         * Time: 12:39
     */

    if(basename(__FILE__) == basename($_SERVER['PHP_SELF'])){exit();}

    session_set_cookie_params(432000);
    ini_set('session.gc_maxlifetime', 432000);

    session_start();