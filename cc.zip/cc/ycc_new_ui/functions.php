<?php


function ajax_output( $array )
{
    echo json_encode($array);
    exit;
}

/**
 * @return array[total_login_agent, total_outbound_agent, total_closer_agent]
 */
function getCurrentLoginAgent($sendMetric = false) {
    global $link;
    $return  = [
        'total_login_agent' => 10,
        'total_outbound_agent' => 10,
        'total_closer_agent' => 10,
    ];
}
?>
