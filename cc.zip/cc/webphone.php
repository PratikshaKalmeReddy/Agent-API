

<!DOCTYPE html>
<html>
<head>

<style>
table, th, td {
  border: 1px solid black;
}
</style>
</head>
<body>

<h2>Table With Border</h2>

<p>Use the CSS border property to add a border to the table.</p>

<table style="width:100%">
  <tr>
    <th>Firstname</th>
    <th>Lastname</th> 
    <th>Age</th>
  </tr>

</table>

</body>
</html>


<script src="https://jssip.net/download/releases/jssip-3.10.0.min.js"></script>
<script>
  
  this.ua = null;


       //  socket = new JsSIP.WebSocketInterface('wss:/sip.myhost.com');
         var   sockets = new JsSIP.WebSocketInterface(
            'wss://api-webrtc-prod.ytel.com:7443',
          )
    
          var contact_uri = new JsSIP.URI(
            'sip',
            '563fd143-9fec-4baa-a545-af5b791bbb3e',
            'ytel.com',
          ).toString()
    
       var    configuration = {
            sockets: [sockets],
            uri: contact_uri,
            contact_uri: contact_uri,
            display_name: '563fd143-9fec-4baa-a545-af5b791bbb3e@ytel.com',
            authorization_user: '563fd143-9fec-4baa-a545-af5b791bbb3e',
            password: '563fd143-9fec-4baa-a545-af5b791bbb3e',
            realm: 'ytel.com',
            register: false,
            register_expires: 120,
            // use_preloaded_route: true,
          }
          JsSIP.debug.enable('JsSIP:*');
     
          console.log(JsSIP.version);
          const token ="eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI1NjNmZDE0My05ZmVjLTRiYWEtYTU0NS1hZjViNzkxYmJiM2UiLCJ1SGFzaCI6IjU5ZTY0MjNkNTMyY2I1ODVkODBiOTM5NDgxZGM4MWIyNzQ1OTA5MjQ5YThhZWZmNzIxNTU0MTJlZTgwNTc5MTgiLCJwQWNjdCI6IjdjODY5M2M2LTk3NmUtNDMyNC05MTIzLTJjMWQ4MTE2MDVmOSIsImFjY3QiOiI3Yzg2OTNjNi05NzZlLTQzMjQtOTEyMy0yYzFkODExNjA1ZjkiLCJwcml2cyI6Wzg2ODY3OTYzMyw1MzY4MzA0MzIsMjA5NzIxNV0sInVzZXJuYW1lIjoicWF0ZWFtQHl0ZWwuY29tIiwic2NvcGUiOiJST0xFX0FDQ0VTU19UT0tFTiIsImlzcyI6Imh0dHBzOi8veXRlbC5jb20iLCJpYXQiOjE3Mzc1NjIwODUsImV4cCI6MTczNzU2OTI4NX0.g4C-qVPMlsusnYFXAE1JjkxLc8_uCU1YJXgT6B-mwkpjBIo6o2k9l1ys96GIuedXAnFqdW7m5xodiFJVC--wgvTWDQ73fHOcz4yMuptfhkNb1UIMOx0xDIjYQDvFWALDfSLfKipjr1G0haBNdizLJIl6vZ59P8MhXtQPoZdsUmnyfUskmldug6KUUqbTCmNIoEcxoe1GD0nfwAgfWYFjQY46CSyaNCgxaZSLCYFTGuWTltfrzmirgEixUVzf-2vpktt97zmAZ18Uj-py7o0SxxDE1tuZdqRAR3HoTWELBWvMCkD1yisF8fTRiA5EzGbw4YgpJPcJmyqbxxOj0KiMag";
         
          this.ua = new JsSIP.UA(configuration)
          console.log("CCCCC----->11111111")
          console.log(this.ua)
        //   console.log(coolPhone.registrator().setExtraHeaders)

        //  coolPhone.registrator.setExtraHeaders(extraHeadersRef.current)
      this.ua.registrator().setExtraHeaders(['X-User_Info: ' + token]);
      this.ua.start();
      this.ua.register();
       this.ua.on('connecting', (data) => {
            //ylogger.sipDebug('jssip.event.ua.connecting', data)
            alert("Coonecting")
            // setSipState({
            //   sipStatus: SIP_STATUS_CONNECTING,
            //   sipIsConnected: false,
            //   sipIsRegistered: false,
            //   sipErrorType: null,
            //   sipErrorMessage: null
            // })
          })

          this.ua.on('connected', (data) => {
            alert("Coonected")
          })

          this.ua.on('disconnected', (data) => {
            alert("disconnected")
          })
          this.ua.on('registered', (data) => {
            alert("registered")
          })
          this.ua.on('disconnected', (data) => {
            alert("disconnected")
          })
          this.ua.on('registrationFailed', (data) => {
            alert("registrationFailed")
          })
</script>


